// Application state and constants
const STORAGE_KEY_PROFILES = 'nexus_profiles_v1';
const STORAGE_KEY_AUTH = 'nexus_auth_v1';

const AppRoute = {
    LOGIN: 'login',
    DASHBOARD: 'dashboard',
    IMPORT: 'import',
    PROFILES: 'profiles'
};

class NexusApp {
    constructor() {
        this.currentRoute = AppRoute.LOGIN;
        this.user = null;
        this.profiles = [];
        this.selectedProfile = null;
        this.isProcessing = false;
        
        this.init();
    }

    init() {
        this.loadStoredData();
        this.render();
        this.setupEventListeners();
    }

    loadStoredData() {
        // Load profiles
        const storedProfiles = localStorage.getItem(STORAGE_KEY_PROFILES);
        if (storedProfiles) {
            this.profiles = JSON.parse(storedProfiles);
        }

        // Load auth
        const storedAuth = localStorage.getItem(STORAGE_KEY_AUTH);
        if (storedAuth) {
            this.user = JSON.parse(storedAuth);
            this.currentRoute = AppRoute.DASHBOARD;
        }
    }

    saveProfiles() {
        localStorage.setItem(STORAGE_KEY_PROFILES, JSON.stringify(this.profiles));
    }

    render() {
        const root = document.getElementById('root');
        
        if (this.currentRoute === AppRoute.LOGIN) {
            this.renderLogin(root);
        } else {
            this.renderMainApp(root);
        }
    }

    renderLogin(container) {
        const template = document.getElementById('login-template');
        const clone = template.content.cloneNode(true);
        
        container.innerHTML = '';
        container.appendChild(clone);
        
        this.setupLoginEventListeners();
    }

    renderMainApp(container) {
        const template = document.getElementById('main-app-template');
        const clone = template.content.cloneNode(true);
        
        container.innerHTML = '';
        container.appendChild(clone);
        
        this.updateUserInfo();
        this.updateNavigation();
        this.renderCurrentView();
        this.setupMainAppEventListeners();
    }

    updateUserInfo() {
        if (!this.user) return;
        
        const userAvatar = document.getElementById('user-avatar');
        const userName = document.getElementById('user-name');
        const userRole = document.getElementById('user-role');
        const welcomeText = document.getElementById('welcome-text');
        
        if (userAvatar) userAvatar.textContent = this.user.username.charAt(0).toUpperCase();
        if (userName) userName.textContent = this.user.username;
        if (userRole) userRole.textContent = this.user.role;
        if (welcomeText) welcomeText.textContent = `Welcome back, ${this.user.username}.`;
    }

    updateNavigation() {
        const navButtons = document.querySelectorAll('.nav-btn');
        const pageTitle = document.getElementById('page-title');
        const newImportBtn = document.getElementById('new-import-btn');
        
        navButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.id === `nav-${this.currentRoute}`) {
                btn.classList.add('active');
            }
        });
        
        if (pageTitle) {
            pageTitle.textContent = this.currentRoute.replace('-', ' ');
        }
        
        if (newImportBtn) {
            newImportBtn.style.display = this.currentRoute === AppRoute.IMPORT ? 'none' : 'flex';
        }
    }

    renderCurrentView() {
        const contentArea = document.getElementById('content-area');
        if (!contentArea) return;
        
        switch (this.currentRoute) {
            case AppRoute.DASHBOARD:
                this.renderDashboard(contentArea);
                break;
            case AppRoute.IMPORT:
                this.renderImport(contentArea);
                break;
            case AppRoute.PROFILES:
                this.renderProfiles(contentArea);
                break;
        }
    }

    renderDashboard(container) {
        const lastActivity = this.profiles.length > 0 
            ? new Date(this.profiles[0].createdAt).toLocaleDateString() 
            : 'No data';

        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in">
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div class="bg-blue-50 w-12 h-12 rounded-xl flex items-center justify-center text-blue-600 mb-4">
                        <i class="fas fa-users text-xl"></i>
                    </div>
                    <p class="text-slate-500 text-sm font-medium">Total Profiles</p>
                    <h3 class="text-3xl font-bold text-slate-900 mt-1">${this.profiles.length}</h3>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div class="bg-emerald-50 w-12 h-12 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
                        <i class="fas fa-qrcode text-xl"></i>
                    </div>
                    <p class="text-slate-500 text-sm font-medium">Active QR Codes</p>
                    <h3 class="text-3xl font-bold text-slate-900 mt-1">${this.profiles.length}</h3>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div class="bg-purple-50 w-12 h-12 rounded-xl flex items-center justify-center text-purple-600 mb-4">
                        <i class="fas fa-clock text-xl"></i>
                    </div>
                    <p class="text-slate-500 text-sm font-medium">Last Activity</p>
                    <h3 class="text-lg font-bold text-slate-900 mt-1">${lastActivity}</h3>
                </div>

                <div class="md:col-span-3 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
                    <h4 class="text-xl font-bold mb-6">Recent Activity</h4>
                    ${this.renderRecentActivity()}
                </div>
            </div>
        `;
    }

    renderRecentActivity() {
        if (this.profiles.length === 0) {
            return `
                <div class="text-center py-12">
                    <div class="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-folder-open text-slate-300 text-2xl"></i>
                    </div>
                    <p class="text-slate-400">No profiles generated yet.</p>
                </div>
            `;
        }

        return `
            <div class="space-y-4">
                ${this.profiles.slice(0, 5).map(profile => `
                    <div class="flex items-center justify-between p-4 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors">
                        <div class="flex items-center gap-4">
                            <div class="bg-indigo-100 w-10 h-10 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                                ${profile.fullName.charAt(0)}
                            </div>
                            <div>
                                <p class="font-bold text-slate-900">${profile.fullName}</p>
                                <p class="text-xs text-slate-500">${profile.role}</p>
                            </div>
                        </div>
                        <span class="text-xs text-slate-400">Added ${new Date(profile.createdAt).toLocaleDateString()}</span>
                    </div>
                `).join('')}
            </div>
        `;
    }

    renderImport(container) {
        container.innerHTML = `
            <div class="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-slate-100 animate-in">
                <div class="mb-8">
                    <h3 class="text-2xl font-bold text-slate-900">Process Sheet or CSV</h3>
                    <p class="text-slate-500 mt-2">Upload a CSV file or paste raw content. AI will structure the data and generate your QR identity profiles.</p>
                </div>
                
                <div class="space-y-6">
                    <div id="file-upload-zone" class="upload-zone border-2 border-dashed border-slate-200 rounded-2xl p-8 transition-all cursor-pointer text-center group">
                        <input type="file" id="file-input" class="hidden" accept=".csv,.txt">
                        <div class="upload-icon bg-indigo-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-transform">
                            <i class="fas fa-file-csv text-indigo-600 text-2xl"></i>
                        </div>
                        <div id="file-status">
                            <p class="font-bold text-slate-900 text-lg">Click to upload CSV</p>
                            <p class="text-slate-500 text-sm mt-1">or drag and drop your file here</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-4">
                        <div class="flex-1 h-px bg-slate-100"></div>
                        <span class="text-xs font-bold text-slate-300 uppercase tracking-widest">or paste manually</span>
                        <div class="flex-1 h-px bg-slate-100"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Raw Content Buffer</label>
                        <textarea id="import-text" class="w-full h-40 p-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-mono text-sm" placeholder="Paste your data here if not uploading a file..."></textarea>
                    </div>

                    <div id="import-error" class="hidden p-4 rounded-xl bg-red-50 text-red-600 flex items-center gap-3 border border-red-100">
                        <i class="fas fa-triangle-exclamation"></i> <span></span>
                    </div>

                    <div class="flex items-center justify-between gap-4 pt-4 border-t border-slate-50">
                        <button id="cancel-import" class="px-6 py-3 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-all">
                            Cancel
                        </button>
                        <button id="process-import" class="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white px-10 py-3 rounded-xl font-bold shadow-xl shadow-indigo-100 transition-all flex items-center gap-3">
                            <i class="fas fa-bolt"></i> Generate Profiles
                        </button>
                    </div>
                </div>
            </div>
        `;

        this.setupImportEventListeners();
    }

    renderProfiles(container) {
        if (this.profiles.length === 0) {
            container.innerHTML = `
                <div class="bg-white rounded-3xl p-16 text-center border border-slate-100 shadow-sm animate-in">
                    <div class="bg-indigo-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 text-indigo-400">
                        <i class="fas fa-user-plus text-4xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-slate-900 mb-2">No Profiles Yet</h3>
                    <p class="text-slate-500 max-w-sm mx-auto mb-8">Import data from a CSV file to start generating secure ID profiles and QR codes.</p>
                    <button id="go-to-import" class="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg">
                        Go to Import
                    </button>
                </div>
            `;
        } else {
            container.innerHTML = `
                <div class="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden animate-in">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="bg-slate-50 border-b border-slate-100">
                                    <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Profile</th>
                                    <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Role/Dept</th>
                                    <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Created</th>
                                    <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Identity</th>
                                    <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                ${this.profiles.map(profile => `
                                    <tr class="table-row transition-colors group">
                                        <td class="px-6 py-5">
                                            <div class="flex items-center gap-4">
                                                <div class="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500">
                                                    ${profile.fullName.charAt(0)}
                                                </div>
                                                <div>
                                                    <p class="font-bold text-slate-900">${profile.fullName}</p>
                                                    <p class="text-sm text-slate-500">${profile.email}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-5">
                                            <p class="text-sm font-medium text-slate-900">${profile.role}</p>
                                            <p class="text-xs text-slate-500">${profile.department}</p>
                                        </td>
                                        <td class="px-6 py-5">
                                            <span class="text-sm text-slate-600">${new Date(profile.createdAt).toLocaleDateString()}</span>
                                        </td>
                                        <td class="px-6 py-5">
                                            <button class="view-qr-btn bg-slate-100 hover:bg-indigo-100 hover:text-indigo-600 p-2 rounded-lg transition-all" data-profile-id="${profile.id}" title="View QR Code">
                                                <i class="fas fa-qrcode"></i>
                                            </button>
                                        </td>
                                        <td class="px-6 py-5 text-right">
                                            <button class="delete-profile-btn text-slate-300 hover:text-red-600 transition-colors p-2" data-profile-id="${profile.id}" title="Delete Profile">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }

        this.setupProfilesEventListeners();
    }

    setupLoginEventListeners() {
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    setupMainAppEventListeners() {
        // Navigation
        document.getElementById('nav-dashboard')?.addEventListener('click', () => this.navigateTo(AppRoute.DASHBOARD));
        document.getElementById('nav-import')?.addEventListener('click', () => this.navigateTo(AppRoute.IMPORT));
        document.getElementById('nav-profiles')?.addEventListener('click', () => this.navigateTo(AppRoute.PROFILES));
        
        // Logout
        document.getElementById('logout-btn')?.addEventListener('click', () => this.handleLogout());
        
        // New import button
        document.getElementById('new-import-btn')?.addEventListener('click', () => this.navigateTo(AppRoute.IMPORT));
    }

    setupImportEventListeners() {
        const fileUploadZone = document.getElementById('file-upload-zone');
        const fileInput = document.getElementById('file-input');
        const importText = document.getElementById('import-text');
        const cancelBtn = document.getElementById('cancel-import');
        const processBtn = document.getElementById('process-import');

        fileUploadZone?.addEventListener('click', () => fileInput?.click());
        fileInput?.addEventListener('change', (e) => this.handleFileUpload(e));
        importText?.addEventListener('input', () => this.clearFileName());
        cancelBtn?.addEventListener('click', () => this.navigateTo(AppRoute.DASHBOARD));
        processBtn?.addEventListener('click', () => this.handleImportData());
    }

    setupProfilesEventListeners() {
        // View QR buttons
        document.querySelectorAll('.view-qr-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const profileId = e.currentTarget.dataset.profileId;
                this.showQRModal(profileId);
            });
        });

        // Delete buttons
        document.querySelectorAll('.delete-profile-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const profileId = e.currentTarget.dataset.profileId;
                this.deleteProfile(profileId);
            });
        });

        // Go to import button
        document.getElementById('go-to-import')?.addEventListener('click', () => this.navigateTo(AppRoute.IMPORT));
    }

    handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value || 'Admin';
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('error-message');
        const errorSpan = errorDiv?.querySelector('span');

        if (password === 'Sohi') {
            this.user = {
                id: '1',
                username: username,
                role: 'SUPER_ADMIN'
            };
            localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(this.user));
            this.navigateTo(AppRoute.DASHBOARD);
            errorDiv?.classList.add('hidden');
        } else {
            if (errorSpan) errorSpan.textContent = 'Invalid credentials. Access denied.';
            errorDiv?.classList.remove('hidden');
        }
    }

    handleLogout() {
        this.user = null;
        localStorage.removeItem(STORAGE_KEY_AUTH);
        this.navigateTo(AppRoute.LOGIN);
    }

    handleFileUpload(e) {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!file.name.toLowerCase().endsWith('.csv') && !file.name.toLowerCase().endsWith('.txt')) {
            this.showError('Please upload a .csv or .txt file.');
            return;
        }

        this.updateFileStatus(file.name);
        const reader = new FileReader();
        reader.onload = (event) => {
            const content = event.target?.result;
            document.getElementById('import-text').value = content;
        };
        reader.readAsText(file);
    }

    updateFileStatus(fileName) {
        const fileStatus = document.getElementById('file-status');
        if (fileStatus) {
            fileStatus.innerHTML = `
                <span class="font-bold text-indigo-600 text-lg mb-1">${fileName}</span>
                <span class="text-slate-400 text-sm block">File loaded successfully</span>
            `;
        }
    }

    clearFileName() {
        const fileStatus = document.getElementById('file-status');
        if (fileStatus) {
            fileStatus.innerHTML = `
                <p class="font-bold text-slate-900 text-lg">Click to upload CSV</p>
                <p class="text-slate-500 text-sm mt-1">or drag and drop your file here</p>
            `;
        }
    }

    async handleImportData() {
        const importText = document.getElementById('import-text').value.trim();
        if (!importText) return;

        const processBtn = document.getElementById('process-import');
        const btnIcon = processBtn?.querySelector('i');
        const btnText = processBtn?.querySelector('span') || processBtn;

        this.isProcessing = true;
        processBtn?.setAttribute('disabled', 'true');
        
        if (btnIcon) btnIcon.className = 'fas fa-spinner spinner';
        if (btnText) btnText.textContent = ' Processing with AI...';

        try {
            // Simulate AI processing (replace with actual API call)
            const newProfiles = await this.processWithAI(importText);
            this.profiles = [...newProfiles, ...this.profiles];
            this.saveProfiles();
            
            document.getElementById('import-text').value = '';
            this.clearFileName();
            this.navigateTo(AppRoute.PROFILES);
        } catch (error) {
            this.showError(error.message || 'Processing failed');
        } finally {
            this.isProcessing = false;
            processBtn?.removeAttribute('disabled');
            if (btnIcon) btnIcon.className = 'fas fa-bolt';
            if (btnText) btnText.textContent = ' Generate Profiles';
        }
    }

    async processWithAI(rawContent) {
        // Simulate AI processing - replace with actual Gemini API call
        return new Promise((resolve) => {
            setTimeout(() => {
                const lines = rawContent.split('\n').filter(line => line.trim());
                const profiles = lines.slice(1).map((line, index) => {
                    const parts = line.split(',').map(part => part.trim());
                    const id = Math.random().toString(36).substr(2, 9);
                    return {
                        id: id,
                        fullName: parts[0] || `Person ${index + 1}`,
                        email: parts[1] || `person${index + 1}@example.com`,
                        role: parts[2] || 'Employee',
                        department: parts[3] || 'General',
                        phone: parts[4] || 'N/A',
                        createdAt: new Date().toISOString(),
                        qrCodeValue: `nexus-profile-${id}`
                    };
                });
                resolve(profiles);
            }, 2000);
        });
    }

    showError(message) {
        const errorDiv = document.getElementById('import-error');
        const errorSpan = errorDiv?.querySelector('span');
        if (errorSpan) errorSpan.textContent = message;
        errorDiv?.classList.remove('hidden');
    }

    deleteProfile(profileId) {
        this.profiles = this.profiles.filter(p => p.id !== profileId);
        this.saveProfiles();
        this.renderCurrentView();
    }

    showQRModal(profileId) {
        const profile = this.profiles.find(p => p.id === profileId);
        if (!profile) return;

        const template = document.getElementById('qr-modal-template');
        const clone = template.content.cloneNode(true);
        
        // Update modal content
        clone.querySelector('#modal-name').textContent = profile.fullName;
        clone.querySelector('#modal-role').textContent = `${profile.role} • ${profile.department}`;
        
        // Add to DOM first
        document.body.appendChild(clone);
        
        // Create QR data with all profile information
        const qrData = JSON.stringify({
            name: profile.fullName,
            email: profile.email,
            role: profile.role,
            department: profile.department,
            phone: profile.phone,
            id: profile.id,
            created: profile.createdAt
        });
        
        // Generate QR code after adding to DOM with delay
        setTimeout(() => {
            const canvas = document.querySelector('#qr-canvas');
            if (canvas && window.QRCode) {
                QRCode.toCanvas(canvas, qrData, { width: 200, margin: 2 });
            }
        }, 100);
        
        // Add event listeners
        document.querySelector('#print-btn').addEventListener('click', () => window.print());
        document.querySelector('#close-modal-btn').addEventListener('click', () => this.closeQRModal());
    }

    closeQRModal() {
        const modal = document.querySelector('.fixed.inset-0');
        modal?.remove();
    }

    navigateTo(route) {
        this.currentRoute = route;
        this.render();
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new NexusApp();
});