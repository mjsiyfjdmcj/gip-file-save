<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class NexusAPI {
    private $dataFile = 'data/profiles.json';
    private $authFile = 'data/auth.json';
    
    public function __construct() {
        // Create data directory if it doesn't exist
        if (!is_dir('data')) {
            mkdir('data', 0755, true);
        }
        
        // Initialize files if they don't exist
        if (!file_exists($this->dataFile)) {
            file_put_contents($this->dataFile, json_encode([]));
        }
        if (!file_exists($this->authFile)) {
            file_put_contents($this->authFile, json_encode([]));
        }
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $pathParts = explode('/', trim($path, '/'));
        
        try {
            switch ($method) {
                case 'POST':
                    return $this->handlePost($pathParts);
                case 'GET':
                    return $this->handleGet($pathParts);
                case 'PUT':
                    return $this->handlePut($pathParts);
                case 'DELETE':
                    return $this->handleDelete($pathParts);
                default:
                    throw new Exception('Method not allowed', 405);
            }
        } catch (Exception $e) {
            http_response_code($e->getCode() ?: 500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
    
    private function handlePost($pathParts) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($pathParts[0]) {
            case 'login':
                return $this->login($input);
            case 'process-data':
                return $this->processData($input);
            case 'profiles':
                return $this->createProfile($input);
            default:
                throw new Exception('Endpoint not found', 404);
        }
    }
    
    private function handleGet($pathParts) {
        switch ($pathParts[0]) {
            case 'profiles':
                return $this->getProfiles();
            case 'profile':
                if (isset($pathParts[1])) {
                    return $this->getProfile($pathParts[1]);
                }
                throw new Exception('Profile ID required', 400);
            default:
                throw new Exception('Endpoint not found', 404);
        }
    }
    
    private function handlePut($pathParts) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($pathParts[0]) {
            case 'profile':
                if (isset($pathParts[1])) {
                    return $this->updateProfile($pathParts[1], $input);
                }
                throw new Exception('Profile ID required', 400);
            default:
                throw new Exception('Endpoint not found', 404);
        }
    }
    
    private function handleDelete($pathParts) {
        switch ($pathParts[0]) {
            case 'profile':
                if (isset($pathParts[1])) {
                    return $this->deleteProfile($pathParts[1]);
                }
                throw new Exception('Profile ID required', 400);
            default:
                throw new Exception('Endpoint not found', 404);
        }
    }
    
    private function login($input) {
        $username = $input['username'] ?? 'Admin';
        $password = $input['password'] ?? '';
        
        if ($password === 'Sohi') {
            $user = [
                'id' => '1',
                'username' => $username,
                'role' => 'SUPER_ADMIN',
                'loginTime' => date('c')
            ];
            
            // Save auth session
            $authData = json_decode(file_get_contents($this->authFile), true);
            $authData[$user['id']] = $user;
            file_put_contents($this->authFile, json_encode($authData, JSON_PRETTY_PRINT));
            
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid credentials. Access denied.']);
        }
    }
    
    private function processData($input) {
        $rawContent = $input['content'] ?? '';
        
        if (empty($rawContent)) {
            throw new Exception('No content provided', 400);
        }
        
        // Simple CSV parsing
        $lines = array_filter(explode("\n", $rawContent));
        $profiles = [];
        
        // Skip header if it exists
        $dataLines = count($lines) > 1 && $this->isHeaderLine($lines[0]) ? array_slice($lines, 1) : $lines;
        
        foreach ($dataLines as $index => $line) {
            $parts = array_map('trim', str_getcsv($line));
            
            if (count($parts) >= 3) { // At least name, email, role
                $id = $this->generateId();
                $profile = [
                    'id' => $id,
                    'fullName' => $parts[0] ?? "Person " . ($index + 1),
                    'email' => $parts[1] ?? "person" . ($index + 1) . "@example.com",
                    'role' => $parts[2] ?? 'Employee',
                    'department' => $parts[3] ?? 'General',
                    'phone' => $parts[4] ?? 'N/A',
                    'createdAt' => date('c'),
                    'qrCodeValue' => "nexus-profile-{$id}"
                ];
                $profiles[] = $profile;
            }
        }
        
        if (empty($profiles)) {
            throw new Exception('No valid profiles found in the data', 400);
        }
        
        // Save profiles
        $existingProfiles = json_decode(file_get_contents($this->dataFile), true);
        $allProfiles = array_merge($profiles, $existingProfiles);
        file_put_contents($this->dataFile, json_encode($allProfiles, JSON_PRETTY_PRINT));
        
        echo json_encode(['success' => true, 'profiles' => $profiles, 'count' => count($profiles)]);
    }
    
    private function getProfiles() {
        $profiles = json_decode(file_get_contents($this->dataFile), true);
        echo json_encode($profiles);
    }
    
    private function getProfile($id) {
        $profiles = json_decode(file_get_contents($this->dataFile), true);
        $profile = array_filter($profiles, function($p) use ($id) {
            return $p['id'] === $id;
        });
        
        if (empty($profile)) {
            throw new Exception('Profile not found', 404);
        }
        
        echo json_encode(array_values($profile)[0]);
    }
    
    private function createProfile($input) {
        $profile = [
            'id' => $this->generateId(),
            'fullName' => $input['fullName'] ?? '',
            'email' => $input['email'] ?? '',
            'role' => $input['role'] ?? '',
            'department' => $input['department'] ?? 'General',
            'phone' => $input['phone'] ?? 'N/A',
            'createdAt' => date('c'),
            'qrCodeValue' => "nexus-profile-" . $this->generateId()
        ];
        
        $profiles = json_decode(file_get_contents($this->dataFile), true);
        array_unshift($profiles, $profile);
        file_put_contents($this->dataFile, json_encode($profiles, JSON_PRETTY_PRINT));
        
        echo json_encode(['success' => true, 'profile' => $profile]);
    }
    
    private function updateProfile($id, $input) {
        $profiles = json_decode(file_get_contents($this->dataFile), true);
        $updated = false;
        
        foreach ($profiles as &$profile) {
            if ($profile['id'] === $id) {
                $profile = array_merge($profile, $input);
                $profile['updatedAt'] = date('c');
                $updated = true;
                break;
            }
        }
        
        if (!$updated) {
            throw new Exception('Profile not found', 404);
        }
        
        file_put_contents($this->dataFile, json_encode($profiles, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'Profile updated']);
    }
    
    private function deleteProfile($id) {
        $profiles = json_decode(file_get_contents($this->dataFile), true);
        $originalCount = count($profiles);
        
        $profiles = array_filter($profiles, function($p) use ($id) {
            return $p['id'] !== $id;
        });
        
        if (count($profiles) === $originalCount) {
            throw new Exception('Profile not found', 404);
        }
        
        file_put_contents($this->dataFile, json_encode(array_values($profiles), JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'Profile deleted']);
    }
    
    private function generateId() {
        return substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 9);
    }
    
    private function isHeaderLine($line) {
        $headers = ['name', 'email', 'role', 'department', 'phone', 'fullname'];
        $lineLower = strtolower($line);
        
        foreach ($headers as $header) {
            if (strpos($lineLower, $header) !== false) {
                return true;
            }
        }
        return false;
    }
}

// Initialize and handle request
$api = new NexusAPI();
$api->handleRequest();
?>