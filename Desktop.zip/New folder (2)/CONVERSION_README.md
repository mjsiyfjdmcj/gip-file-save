# Nexus Profile Manager - Converted Files

This directory contains the converted files from the original React/TSX application to vanilla HTML, CSS, JavaScript, and PHP.

## Files Overview

### Core Files
- `index_converted.html` - Main HTML file with all templates
- `styles.css` - All styles converted from Tailwind classes
- `app.js` - Basic JavaScript version (localStorage only)
- `app-enhanced.js` - Enhanced version with PHP API integration
- `api.php` - PHP backend for data persistence

### Original Files (for reference)
- `App.tsx` - Original React component
- `index.tsx` - Original React entry point
- `components/QRCodeViewer.tsx` - Original QR modal component
- `types.ts` - TypeScript interfaces
- `services/geminiService.ts` - Original Gemini AI service

## Setup Instructions

### Option 1: Basic HTML/JS Version (No Server Required)
1. Open `index_converted.html` in a web browser
2. Update the script tag to use `app.js`:
   ```html
   <script src="app.js"></script>
   ```
3. All data will be stored in localStorage

### Option 2: Full PHP Version (Requires Web Server)
1. Set up a web server with PHP support (Apache, Nginx, or local server like XAMPP)
2. Copy all files to your web root directory
3. Update the script tag to use the enhanced version:
   ```html
   <script src="app-enhanced.js"></script>
   ```
4. Create a `data/` directory with write permissions for PHP
5. Access via your web server (e.g., `http://localhost/nexus/`)

## Features Converted

### ✅ Completed
- Login system with password authentication
- Dashboard with statistics and recent activity
- CSV/TXT file import with drag & drop
- Profile management (create, view, delete)
- QR code generation and display
- Responsive design
- Local storage persistence
- PHP API backend
- Export functionality (CSV/JSON)

### 🔄 Differences from Original
- **AI Processing**: Simplified CSV parsing instead of Gemini AI (can be enhanced)
- **QR Generation**: Uses qrcode.js library instead of qrcode.react
- **Styling**: Custom CSS instead of Tailwind (maintains same appearance)
- **State Management**: Vanilla JS classes instead of React hooks
- **Routing**: Manual route handling instead of React Router

## Configuration

### Authentication
- Default password: `Sohi`
- Can be changed in both `app.js` and `api.php`

### API Endpoints (PHP version)
- `POST /api.php/login` - User authentication
- `GET /api.php/profiles` - Get all profiles
- `POST /api.php/process-data` - Process CSV data
- `POST /api.php/profiles` - Create new profile
- `PUT /api.php/profile/{id}` - Update profile
- `DELETE /api.php/profile/{id}` - Delete profile

### File Upload Limits
- Maximum file size: 5MB
- Supported formats: CSV, TXT, TSV
- Automatic header detection

## Browser Compatibility
- Modern browsers (Chrome 60+, Firefox 55+, Safari 12+, Edge 79+)
- Requires JavaScript enabled
- Uses modern ES6+ features

## Security Notes
- Change default password before deployment
- Implement proper session management for production
- Add CSRF protection for PHP API
- Validate and sanitize all inputs
- Use HTTPS in production

## Customization

### Styling
Edit `styles.css` to modify colors, fonts, and layout.

### Branding
Update logo, colors, and text in the HTML templates.

### Data Processing
Enhance the `processWithAI()` function in JavaScript or add real AI integration to the PHP backend.

## Troubleshooting

### Common Issues
1. **QR codes not showing**: Ensure qrcode.js library is loaded
2. **File upload not working**: Check file permissions and size limits
3. **API errors**: Verify PHP configuration and data directory permissions
4. **Styling issues**: Ensure styles.css is properly linked

### Debug Mode
Add `?debug=1` to URL to enable console logging in the enhanced version.

## Performance Optimization
- Minify CSS and JavaScript for production
- Optimize images and icons
- Enable gzip compression on server
- Use CDN for external libraries
- Implement caching strategies

## Future Enhancements
- Real AI integration (Gemini API)
- Advanced user management
- Bulk operations
- Data analytics
- Mobile app version
- Advanced QR code customization