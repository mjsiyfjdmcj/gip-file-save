
import { Training, VisitorStats } from '../types';

const STORAGE_KEY = 'brighters_trainings';
const HISTORY_KEY = 'brighters_history';
const STATS_KEY = 'brighters_stats';

export const TrainingService = {
  getTrainings: (): Training[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  getTrainingById: (id: string): Training | undefined => {
    return TrainingService.getTrainings().find(t => t.id === id);
  },

  saveTraining: (training: Training) => {
    const trainings = TrainingService.getTrainings();
    const index = trainings.findIndex(t => t.id === training.id);
    
    if (index > -1) {
      trainings[index] = training;
    } else {
      trainings.push({ ...training, createdAt: Date.now() });
    }
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trainings));
  },

  deleteTraining: (id: string) => {
    const trainings = TrainingService.getTrainings();
    const trainingToDelete = trainings.find(t => t.id === id);
    
    if (trainingToDelete) {
      // Add to history before deleting
      const history = TrainingService.getHistory();
      history.push({ ...trainingToDelete, deletedAt: Date.now() });
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
      
      const filtered = trainings.filter(t => t.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    }
  },

  getHistory: (): any[] => {
    const data = localStorage.getItem(HISTORY_KEY);
    return data ? JSON.parse(data) : [];
  },

  restoreTraining: (id: string) => {
    const history = TrainingService.getHistory();
    const trainingToRestore = history.find(t => t.id === id);
    
    if (trainingToRestore) {
      const { deletedAt, ...training } = trainingToRestore;
      TrainingService.saveTraining(training);
      const filtered = history.filter(t => t.id !== id);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered));
    }
  },

  trackVisitor: () => {
    const statsStr = localStorage.getItem(STATS_KEY);
    let stats: VisitorStats = statsStr ? JSON.parse(statsStr) : { total: 0, today: 0 };
    
    const lastTracked = localStorage.getItem('last_tracked_date');
    const today = new Date().toLocaleDateString();
    
    if (lastTracked !== today) {
      stats.today = 0;
      localStorage.setItem('last_tracked_date', today);
    }
    
    stats.total += 1;
    stats.today += 1;
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  },

  getStats: (): VisitorStats => {
    const statsStr = localStorage.getItem(STATS_KEY);
    return statsStr ? JSON.parse(statsStr) : { total: 0, today: 0 };
  }
};
