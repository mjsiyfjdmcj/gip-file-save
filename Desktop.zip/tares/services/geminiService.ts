
import { GoogleGenAI } from "@google/genai";

export const geminiService = {
  generateCourseContent: async (topic: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are 'Brighters AI', a professional curriculum developer for an English Training Academy.
      Please help create a detailed training description and curriculum for the topic: "${topic}".
      Return the output as Markdown with sections for 'Overview', 'What You Will Learn', and 'Module Breakdown'.`,
      config: {
        systemInstruction: "You assist administrators of the Brighters Academy in creating high-quality training posts.",
        temperature: 0.7,
      },
    });
    return response.text;
  }
};
