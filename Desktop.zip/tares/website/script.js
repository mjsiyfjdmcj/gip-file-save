document.addEventListener('DOMContentLoaded', function() {
    loadCourses();
    trackVisitor();
});

async function loadCourses() {
    const loading = document.getElementById('loading');
    const coursesGrid = document.getElementById('courses-grid');
    const noCourses = document.getElementById('no-courses');

    try {
        const response = await fetch('api.php?action=get_courses');
        const courses = await response.json();

        loading.style.display = 'none';

        if (courses.length === 0) {
            noCourses.style.display = 'block';
        } else {
            coursesGrid.innerHTML = courses.map(course => createCourseCard(course)).join('');
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        loading.textContent = 'Error loading courses';
    }
}

function createCourseCard(course) {
    const formatDateTime = (dateTime) => {
        return new Date(dateTime).toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return `
        <div class="course-card">
            <div class="course-image">
                ${course.image ? 
                    `<img src="${course.image}" alt="${course.name}">` :
                    `<div class="placeholder"><i class="fas fa-image"></i></div>`
                }
                <div class="course-fee">৳${course.fee}</div>
            </div>
            <div class="course-content">
                <h3 class="course-title">${course.name}</h3>
                <div class="course-meta">
                    <div class="course-meta-item">
                        <i class="fas fa-building"></i>
                        <span>${course.organization}</span>
                    </div>
                    <div class="course-meta-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>${formatDateTime(course.dateTime)}</span>
                    </div>
                </div>
                <p class="course-description">${course.description}</p>
                <div class="course-actions">
                    <button class="btn btn-secondary" onclick="showDetails('${course.id}')">Details</button>
                    <a href="${course.applyLink || 'https://forms.gle/default'}" 
                       target="_blank" 
                       class="btn btn-primary">Apply Now</a>
                </div>
            </div>
        </div>
    `;
}

function showDetails(courseId) {
    fetch(`api.php?action=get_course&id=${courseId}`)
        .then(response => response.json())
        .then(course => {
            if (course) {
                alert(`Course Details:\n\nName: ${course.name}\nOrganization: ${course.organization}\nFee: ৳${course.fee}\nDescription: ${course.description}`);
            }
        })
        .catch(error => console.error('Error:', error));
}

async function trackVisitor() {
    try {
        await fetch('api.php?action=track_visitor', { method: 'POST' });
    } catch (error) {
        console.error('Error tracking visitor:', error);
    }
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.getElementById('header');
    if (window.scrollY > 20) {
        header.style.background = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.1)';
    } else {
        header.style.background = 'rgba(255, 255, 255, 0.9)';
        header.style.boxShadow = 'none';
    }
});