# Brighters Academy Website

A professional training website built with HTML, CSS, JavaScript, and PHP with live posts functionality.

## Features

- **Responsive Design**: Mobile-friendly layout using modern CSS
- **Live Posts**: Dynamic course loading from PHP backend
- **Admin Panel**: Full CRUD operations for managing courses
- **Visitor Tracking**: Real-time statistics tracking
- **Professional UI**: Clean, modern interface with smooth animations

## Setup Instructions

### Prerequisites
- PHP 7.4 or higher
- Web server (Apache/Nginx) or PHP built-in server
- Modern web browser

### Installation

1. **Upload files to your web server**
   ```
   website/
   ├── index.html          # Main homepage
   ├── admin.php           # Admin panel
   ├── api.php             # Backend API
   ├── styles.css          # Stylesheet
   ├── script.js           # Frontend JavaScript
   └── data/               # Data storage
       ├── courses.json    # Course data
       └── stats.json      # Visitor statistics
   ```

2. **Set proper permissions**
   ```bash
   chmod 755 website/
   chmod 666 website/data/*.json
   chmod 755 website/data/
   ```

3. **Access the website**
   - Main site: `http://yourdomain.com/website/`
   - Admin panel: `http://yourdomain.com/website/admin.php`

### Local Development

For local testing, use PHP's built-in server:

```bash
cd website
php -S localhost:8000
```

Then visit:
- Main site: http://localhost:8000
- Admin panel: http://localhost:8000/admin.php

## API Endpoints

### GET Requests
- `api.php?action=get_courses` - Get all courses
- `api.php?action=get_course&id={id}` - Get specific course
- `api.php?action=get_stats` - Get visitor statistics

### POST Requests
- `api.php?action=add_course` - Add new course
- `api.php?action=update_course` - Update existing course
- `api.php?action=delete_course` - Delete course
- `api.php?action=track_visitor` - Track visitor

## Admin Panel Features

1. **Dashboard**: View visitor statistics and course count
2. **Manage Courses**: Edit/delete existing courses
3. **Add Course**: Create new training posts
4. **Real-time Updates**: Changes reflect immediately on the main site

## Course Data Structure

```json
{
  "id": "unique_id",
  "name": "Course Name",
  "description": "Course description",
  "organization": "Organization Name", 
  "dateTime": "2024-02-15T10:00:00",
  "fee": 5000,
  "image": "https://example.com/image.jpg",
  "applyLink": "https://forms.gle/example",
  "createdAt": 1704067200000
}
```

## Customization

### Styling
Edit `styles.css` to customize colors, fonts, and layout.

### Functionality
Modify `script.js` for frontend behavior and `api.php` for backend logic.

### Content
Use the admin panel to manage courses, or directly edit `data/courses.json`.

## Security Notes

- Ensure proper file permissions on production servers
- Consider adding authentication to the admin panel
- Validate and sanitize all user inputs
- Use HTTPS in production

## Browser Support

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+

## License

This project is open source and available under the MIT License.