<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class CourseAPI {
    private $dataFile = 'data/courses.json';
    private $statsFile = 'data/stats.json';
    
    public function __construct() {
        if (!file_exists('data')) {
            mkdir('data', 0777, true);
        }
        
        if (!file_exists($this->dataFile)) {
            file_put_contents($this->dataFile, json_encode([]));
        }
        
        if (!file_exists($this->statsFile)) {
            file_put_contents($this->statsFile, json_encode(['total' => 0, 'today' => 0, 'lastDate' => date('Y-m-d')]));
        }
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'get_courses':
                $this->getCourses();
                break;
            case 'get_course':
                $this->getCourse($_GET['id'] ?? '');
                break;
            case 'add_course':
                if ($method === 'POST') {
                    $this->addCourse();
                }
                break;
            case 'update_course':
                if ($method === 'POST') {
                    $this->updateCourse();
                }
                break;
            case 'delete_course':
                if ($method === 'POST') {
                    $this->deleteCourse($_POST['id'] ?? '');
                }
                break;
            case 'track_visitor':
                if ($method === 'POST') {
                    $this->trackVisitor();
                }
                break;
            case 'get_stats':
                $this->getStats();
                break;
            default:
                http_response_code(400);
                echo json_encode(['error' => 'Invalid action']);
        }
    }
    
    private function getCourses() {
        $courses = $this->loadCourses();
        // Sort by creation date, newest first
        usort($courses, function($a, $b) {
            return ($b['createdAt'] ?? 0) - ($a['createdAt'] ?? 0);
        });
        echo json_encode($courses);
    }
    
    private function getCourse($id) {
        $courses = $this->loadCourses();
        $course = array_filter($courses, function($c) use ($id) {
            return $c['id'] === $id;
        });
        
        if (empty($course)) {
            http_response_code(404);
            echo json_encode(['error' => 'Course not found']);
        } else {
            echo json_encode(array_values($course)[0]);
        }
    }
    
    private function addCourse() {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['name']) || !isset($input['organization'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing required fields']);
            return;
        }
        
        $courses = $this->loadCourses();
        
        $course = [
            'id' => uniqid(),
            'name' => $input['name'],
            'description' => $input['description'] ?? '',
            'organization' => $input['organization'],
            'dateTime' => $input['dateTime'] ?? date('c'),
            'fee' => (int)($input['fee'] ?? 0),
            'image' => $input['image'] ?? '',
            'applyLink' => $input['applyLink'] ?? '',
            'createdAt' => time() * 1000 // JavaScript timestamp
        ];
        
        $courses[] = $course;
        $this->saveCourses($courses);
        
        echo json_encode(['success' => true, 'course' => $course]);
    }
    
    private function updateCourse() {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing course ID']);
            return;
        }
        
        $courses = $this->loadCourses();
        $index = -1;
        
        for ($i = 0; $i < count($courses); $i++) {
            if ($courses[$i]['id'] === $input['id']) {
                $index = $i;
                break;
            }
        }
        
        if ($index === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Course not found']);
            return;
        }
        
        // Update course data
        $courses[$index] = array_merge($courses[$index], $input);
        $this->saveCourses($courses);
        
        echo json_encode(['success' => true, 'course' => $courses[$index]]);
    }
    
    private function deleteCourse($id) {
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing course ID']);
            return;
        }
        
        $courses = $this->loadCourses();
        $courses = array_filter($courses, function($c) use ($id) {
            return $c['id'] !== $id;
        });
        
        $this->saveCourses(array_values($courses));
        echo json_encode(['success' => true]);
    }
    
    private function trackVisitor() {
        $stats = $this->loadStats();
        $today = date('Y-m-d');
        
        if ($stats['lastDate'] !== $today) {
            $stats['today'] = 0;
            $stats['lastDate'] = $today;
        }
        
        $stats['total']++;
        $stats['today']++;
        
        $this->saveStats($stats);
        echo json_encode(['success' => true]);
    }
    
    private function getStats() {
        echo json_encode($this->loadStats());
    }
    
    private function loadCourses() {
        $data = file_get_contents($this->dataFile);
        return json_decode($data, true) ?: [];
    }
    
    private function saveCourses($courses) {
        file_put_contents($this->dataFile, json_encode($courses, JSON_PRETTY_PRINT));
    }
    
    private function loadStats() {
        $data = file_get_contents($this->statsFile);
        return json_decode($data, true) ?: ['total' => 0, 'today' => 0, 'lastDate' => date('Y-m-d')];
    }
    
    private function saveStats($stats) {
        file_put_contents($this->statsFile, json_encode($stats, JSON_PRETTY_PRINT));
    }
}

$api = new CourseAPI();
$api->handleRequest();
?>