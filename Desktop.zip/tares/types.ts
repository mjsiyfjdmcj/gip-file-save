
export interface Training {
  id: string;
  name: string;
  description: string;
  organization: string;
  dateTime: string;
  fee: number;
  discountCode?: string;
  image?: string;
  applyLink?: string;
  createdAt: number;
}

export interface VisitorStats {
  total: number;
  today: number;
}

export enum AdminTab {
  DASHBOARD = 'DASHBOARD',
  POSTS = 'POSTS',
  AI_ASSISTANT = 'AI_ASSISTANT',
  HISTORY = 'HISTORY'
}
