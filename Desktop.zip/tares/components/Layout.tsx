
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const isAdminPath = location.pathname.startsWith('/admin');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'glass-morphism shadow-md py-2' : 'bg-transparent py-4'}`}>
        <nav className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg group-hover:rotate-6 transition-transform">
              <i className="fas fa-graduation-cap text-xl"></i>
            </div>
            <div>
              <h1 className={`font-bold text-xl leading-none ${isScrolled ? 'text-indigo-900' : 'text-slate-900'}`}>Brighters</h1>
              <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-semibold">Academy</span>
            </div>
          </Link>
          
          <div className="flex items-center space-x-6">
            {!isAdminPath && (
              <>
                <Link to="/" className="text-slate-600 hover:text-indigo-600 font-medium transition-colors">Courses</Link>
                <Link to="/admin" className="bg-indigo-600 text-white px-5 py-2 rounded-full font-medium hover:bg-indigo-700 transition-all hover:shadow-lg shadow-indigo-200">Admin Login</Link>
              </>
            )}
            {isAdminPath && (
              <Link to="/" className="text-indigo-600 hover:text-indigo-800 font-medium">
                <i className="fas fa-arrow-left mr-2"></i>Exit Dashboard
              </Link>
            )}
          </div>
        </nav>
      </header>

      <main className="flex-grow pt-24 pb-12">
        {children}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white">
                <i className="fas fa-graduation-cap"></i>
              </div>
              <h2 className="text-white font-bold text-lg">Brighters Academy</h2>
            </div>
            <p className="max-w-md">Empowering individuals through professional English training and career development programs. Join thousands of successful students today.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/admin" className="hover:text-white transition-colors">Admin Portal</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li><i className="fas fa-envelope mr-2"></i> info@brighters.com</li>
              <li><i className="fas fa-phone mr-2"></i> +880 1234 567 890</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-slate-800 text-center text-sm">
          &copy; {new Date().getFullYear()} Brighters Academy. All rights reserved. Professional English Training Solutions.
        </div>
      </footer>
    </div>
  );
};

export default Layout;
