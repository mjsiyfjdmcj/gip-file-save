
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';

const AdminLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Mimicking a secure delay for better UX and to prevent brute-force feeling
    setTimeout(() => {
      // In a real production app, this would be a fetch call to a backend API
      // For this implementation, we use static credentials but keep them hidden from hints
      if (username === 'admin' && password === 'admin123') {
        sessionStorage.setItem('isAdmin', 'true');
        navigate('/admin/dashboard');
      } else {
        setError('Invalid username or password. Please try again.');
      }
      setLoading(false);
    }, 800);
  };

  return (
    <Layout>
      <div className="max-w-md mx-auto px-4 pt-10">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 animate-fade-in">
          <div className="bg-indigo-600 p-8 text-center text-white">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-shield-alt text-3xl"></i>
            </div>
            <h2 className="text-2xl font-bold tracking-tight">Admin Authentication</h2>
            <p className="text-indigo-100 text-sm mt-1">Authorized Access Only</p>
          </div>
          
          <form onSubmit={handleLogin} className="p-8 space-y-6">
            {error && (
              <div className="bg-red-50 text-red-700 p-4 rounded-xl text-sm font-medium border border-red-100 flex items-center animate-pulse">
                <i className="fas fa-exclamation-triangle mr-3"></i> {error}
              </div>
            )}
            
            <div>
              <label className="block text-slate-700 font-bold mb-2 text-sm">Username</label>
              <div className="relative group">
                <i className="fas fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors"></i>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:border-transparent outline-none transition-all"
                  placeholder="Enter username"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-2 text-sm">Password</label>
              <div className="relative group">
                <i className="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors"></i>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:border-transparent outline-none transition-all"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-indigo-200 active:scale-[0.98] flex items-center justify-center"
            >
              {loading ? (
                <>
                  <i className="fas fa-circle-notch fa-spin mr-2"></i> Authenticating...
                </>
              ) : (
                'Secure Login'
              )}
            </button>
          </form>
          
          <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
            <p className="text-slate-400 text-xs">
              Contact system administrator if you lost your credentials.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminLogin;
