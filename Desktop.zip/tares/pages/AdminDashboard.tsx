
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { TrainingService } from '../services/trainingService';
import { geminiService } from '../services/geminiService';
import { Training, VisitorStats, AdminTab } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>(AdminTab.DASHBOARD);
  const [trainings, setTrainings] = useState<Training[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [stats, setStats] = useState<VisitorStats>({ total: 0, today: 0 });
  const navigate = useNavigate();

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    description: '',
    organization: 'Brighters Academy',
    dateTime: '',
    fee: 0,
    discountCode: '',
    applyLink: '',
    image: ''
  });

  // AI State
  const [aiTopic, setAiTopic] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem('isAdmin') !== 'true') {
      navigate('/admin');
      return;
    }
    refreshData();
  }, []);

  const refreshData = () => {
    setTrainings(TrainingService.getTrainings());
    setHistory(TrainingService.getHistory());
    setStats(TrainingService.getStats());
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const training: Training = {
      ...form,
      id: editingId || Date.now().toString(),
      createdAt: Date.now()
    };
    TrainingService.saveTraining(training);
    setEditingId(null);
    setForm({
      name: '', description: '', organization: 'Brighters Academy',
      dateTime: '', fee: 0, discountCode: '', applyLink: '', image: ''
    });
    refreshData();
    setActiveTab(AdminTab.POSTS);
  };

  const handleDelete = (id: string) => {
    if (confirm('Move to history?')) {
      TrainingService.deleteTraining(id);
      refreshData();
    }
  };

  const handleEdit = (training: Training) => {
    setEditingId(training.id);
    setForm({
      name: training.name,
      description: training.description,
      organization: training.organization,
      dateTime: training.dateTime,
      fee: training.fee,
      discountCode: training.discountCode || '',
      applyLink: training.applyLink || '',
      image: training.image || ''
    });
    setActiveTab(AdminTab.DASHBOARD);
  };

  const generateWithAI = async () => {
    if (!aiTopic) return;
    setAiLoading(true);
    try {
      const content = await geminiService.generateCourseContent(aiTopic);
      setForm(prev => ({ ...prev, name: aiTopic, description: content || '' }));
      setActiveTab(AdminTab.DASHBOARD);
      alert('Content generated successfully! Review the description.');
    } catch (err) {
      alert('AI Generation failed. Check API Key.');
    } finally {
      setAiLoading(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setForm(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <aside className="md:w-64 space-y-2">
          <button 
            onClick={() => setActiveTab(AdminTab.DASHBOARD)}
            className={`w-full text-left px-6 py-3 rounded-xl font-semibold flex items-center transition-all ${activeTab === AdminTab.DASHBOARD ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <i className="fas fa-plus-circle mr-3"></i> {editingId ? 'Edit Training' : 'Add New'}
          </button>
          <button 
            onClick={() => setActiveTab(AdminTab.POSTS)}
            className={`w-full text-left px-6 py-3 rounded-xl font-semibold flex items-center transition-all ${activeTab === AdminTab.POSTS ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <i className="fas fa-th-list mr-3"></i> Manage Posts
          </button>
          <button 
            onClick={() => setActiveTab(AdminTab.AI_ASSISTANT)}
            className={`w-full text-left px-6 py-3 rounded-xl font-semibold flex items-center transition-all ${activeTab === AdminTab.AI_ASSISTANT ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <i className="fas fa-robot mr-3"></i> Brighters AI
          </button>
          <button 
            onClick={() => setActiveTab(AdminTab.HISTORY)}
            className={`w-full text-left px-6 py-3 rounded-xl font-semibold flex items-center transition-all ${activeTab === AdminTab.HISTORY ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <i className="fas fa-history mr-3"></i> History
          </button>
          <div className="pt-8 border-t border-slate-200 mt-8">
            <div className="p-4 bg-indigo-50 rounded-2xl">
              <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-4">Site Stats</h4>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-2xl font-bold text-indigo-900">{stats.today}</p>
                  <p className="text-[10px] text-indigo-500 font-bold uppercase">Today</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-indigo-900">{stats.total}</p>
                  <p className="text-[10px] text-indigo-500 font-bold uppercase">Total</p>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Content Area */}
        <div className="flex-1">
          {activeTab === AdminTab.DASHBOARD && (
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 animate-fade-in">
              <h2 className="text-2xl font-bold text-slate-900 mb-8">
                {editingId ? 'Update Training Program' : 'Create New Training Program'}
              </h2>
              <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="col-span-full">
                  <label className="block text-sm font-bold text-slate-700 mb-2">Training Name</label>
                  <input 
                    type="text" 
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none"
                    placeholder="e.g. Advanced English Speaking Masterclass"
                    required
                  />
                </div>
                
                <div className="col-span-full">
                  <label className="block text-sm font-bold text-slate-700 mb-2">Description</label>
                  <textarea 
                    value={form.description}
                    onChange={e => setForm({...form, description: e.target.value})}
                    rows={6}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none resize-none"
                    placeholder="Describe what students will learn..."
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Organization</label>
                  <input 
                    type="text" 
                    value={form.organization}
                    onChange={e => setForm({...form, organization: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Date & Time</label>
                  <input 
                    type="datetime-local" 
                    value={form.dateTime}
                    onChange={e => setForm({...form, dateTime: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Fee (৳)</label>
                  <input 
                    type="number" 
                    value={form.fee}
                    onChange={e => setForm({...form, fee: parseInt(e.target.value) || 0})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Discount Code</label>
                  <input 
                    type="text" 
                    value={form.discountCode}
                    onChange={e => setForm({...form, discountCode: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    placeholder="SUMMER2024"
                  />
                </div>

                <div className="col-span-full">
                  <label className="block text-sm font-bold text-slate-700 mb-2">Thumbnail Image</label>
                  <input 
                    type="file" 
                    onChange={handleImageChange}
                    accept="image/*"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                  {form.image && (
                    <div className="mt-4 relative w-32 h-20 rounded-lg overflow-hidden border">
                      <img src={form.image} className="w-full h-full object-cover" />
                      <button onClick={() => setForm({...form, image: ''})} className="absolute top-0 right-0 bg-red-500 text-white p-1 text-[10px]">Remove</button>
                    </div>
                  )}
                </div>

                <div className="col-span-full">
                  <label className="block text-sm font-bold text-slate-700 mb-2">Google Forms/Apply Link</label>
                  <input 
                    type="url" 
                    value={form.applyLink}
                    onChange={e => setForm({...form, applyLink: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    placeholder="https://forms.gle/..."
                  />
                </div>

                <div className="col-span-full flex gap-4 pt-6">
                  <button type="submit" className="flex-1 bg-indigo-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-indigo-700 transition-all">
                    {editingId ? 'Update Post' : 'Publish Live Now'}
                  </button>
                  {editingId && (
                    <button 
                      type="button" 
                      onClick={() => { setEditingId(null); setForm({name: '', description: '', organization: 'Brighters Academy', dateTime: '', fee: 0, discountCode: '', applyLink: '', image: ''})}}
                      className="bg-slate-200 text-slate-700 font-bold px-8 py-4 rounded-xl"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>
          )}

          {activeTab === AdminTab.POSTS && (
            <div className="space-y-4 animate-fade-in">
              <h2 className="text-2xl font-bold text-slate-900 mb-8">Active Training Posts</h2>
              {trainings.length === 0 ? (
                <div className="bg-white p-12 text-center rounded-3xl border">
                  <p className="text-slate-400">No active posts yet.</p>
                </div>
              ) : (
                trainings.map(t => (
                  <div key={t.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-indigo-100 rounded-xl flex items-center justify-center overflow-hidden">
                        {t.image ? <img src={t.image} className="w-full h-full object-cover" /> : <i className="fas fa-graduation-cap text-indigo-400"></i>}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900">{t.name}</h4>
                        <p className="text-xs text-slate-500">{new Date(t.dateTime).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleEdit(t)} className="p-3 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                        <i className="fas fa-edit"></i>
                      </button>
                      <button onClick={() => handleDelete(t.id)} className="p-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === AdminTab.AI_ASSISTANT && (
            <div className="bg-indigo-900 p-12 rounded-3xl text-white animate-fade-in relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <i className="fas fa-robot text-9xl"></i>
              </div>
              <div className="relative z-10">
                <h2 className="text-3xl font-bold mb-4">Brighters AI Assistant</h2>
                <p className="text-indigo-200 mb-8 max-w-xl">Enter a topic and let our AI create a professional course structure and description for your academy.</p>
                
                <div className="space-y-4">
                  <input 
                    type="text" 
                    value={aiTopic}
                    onChange={e => setAiTopic(e.target.value)}
                    className="w-full px-6 py-4 bg-white/10 border border-white/20 rounded-2xl outline-none focus:bg-white/20 transition-all text-white placeholder-indigo-300"
                    placeholder="e.g. Business English Communication 101"
                  />
                  <button 
                    onClick={generateWithAI}
                    disabled={aiLoading}
                    className="bg-white text-indigo-900 px-8 py-4 rounded-xl font-bold hover:bg-indigo-50 transition-all flex items-center"
                  >
                    {aiLoading ? <i className="fas fa-circle-notch fa-spin mr-2"></i> : <i className="fas fa-magic mr-2"></i>}
                    Generate Content
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === AdminTab.HISTORY && (
            <div className="space-y-4 animate-fade-in">
              <h2 className="text-2xl font-bold text-slate-900 mb-8">Training History</h2>
              {history.length === 0 ? (
                <div className="bg-white p-12 text-center rounded-3xl border">
                  <p className="text-slate-400">History is empty.</p>
                </div>
              ) : (
                history.map(t => (
                  <div key={t.id} className="bg-white p-6 rounded-2xl border border-slate-100 flex items-center justify-between opacity-60 grayscale hover:grayscale-0 transition-all hover:opacity-100">
                    <div>
                      <h4 className="font-bold text-slate-900 line-through">{t.name}</h4>
                      <p className="text-xs text-slate-500">Deleted: {new Date(t.deletedAt).toLocaleDateString()}</p>
                    </div>
                    <button 
                      onClick={() => { TrainingService.restoreTraining(t.id); refreshData(); setActiveTab(AdminTab.POSTS); }} 
                      className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-bold"
                    >
                      Restore Post
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default AdminDashboard;
