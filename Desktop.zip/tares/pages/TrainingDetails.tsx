
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { TrainingService } from '../services/trainingService';
import { Training } from '../types';

const TrainingDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [training, setTraining] = useState<Training | null>(null);

  useEffect(() => {
    if (id) {
      const found = TrainingService.getTrainingById(id);
      if (found) setTraining(found);
    }
  }, [id]);

  if (!training) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 text-center py-20">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Training Not Found</h2>
          <Link to="/" className="text-indigo-600 font-semibold underline">Back to Homepage</Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <article className="max-w-4xl mx-auto px-4 animate-fade-in">
        <Link to="/" className="inline-flex items-center text-indigo-600 mb-8 font-semibold hover:text-indigo-800 transition-colors">
          <i className="fas fa-arrow-left mr-2"></i> Back to all programs
        </Link>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
          <div className="h-64 md:h-96 relative overflow-hidden bg-slate-900">
            {training.image && (
              <img src={training.image} alt={training.name} className="w-full h-full object-cover opacity-80" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent flex items-end p-8">
              <div>
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-2">{training.name}</h2>
                <div className="flex flex-wrap gap-4 text-white/90">
                  <span className="flex items-center"><i className="fas fa-building mr-2"></i> {training.organization}</span>
                  <span className="flex items-center"><i className="fas fa-calendar-alt mr-2"></i> {new Date(training.dateTime).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="bg-indigo-50 p-6 rounded-2xl text-center">
                <i className="fas fa-money-bill-wave text-indigo-600 text-2xl mb-2"></i>
                <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider">Fee</h4>
                <p className="text-indigo-900 font-bold text-xl">৳{training.fee}</p>
              </div>
              <div className="bg-green-50 p-6 rounded-2xl text-center">
                <i className="fas fa-tag text-green-600 text-2xl mb-2"></i>
                <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider">Discount Code</h4>
                <p className="text-green-900 font-bold text-xl">{training.discountCode || 'NONE'}</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-2xl text-center">
                <i className="fas fa-users text-blue-600 text-2xl mb-2"></i>
                <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider">Format</h4>
                <p className="text-blue-900 font-bold text-xl">Online/Live</p>
              </div>
            </div>

            <div className="prose prose-indigo max-w-none">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Program Overview</h3>
              <div className="text-slate-700 leading-relaxed whitespace-pre-wrap text-lg">
                {training.description}
              </div>
            </div>

            <div className="mt-12 p-8 bg-slate-900 rounded-3xl text-center text-white">
              <h3 className="text-2xl font-bold mb-4">Limited Seats Available!</h3>
              <p className="text-slate-300 mb-8">Take the next step in your professional journey by joining our upcoming session.</p>
              <a 
                href={training.applyLink || "https://forms.gle/default"} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-4 rounded-full font-bold text-lg transition-all transform hover:scale-105 shadow-xl shadow-indigo-900/40"
              >
                Enroll Now <i className="fas fa-paper-plane ml-2"></i>
              </a>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
};

export default TrainingDetails;
