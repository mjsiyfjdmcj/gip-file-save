
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { TrainingService } from '../services/trainingService';
import { Training } from '../types';

const LandingPage: React.FC = () => {
  const [trainings, setTrainings] = useState<Training[]>([]);

  useEffect(() => {
    TrainingService.trackVisitor();
    setTrainings(TrainingService.getTrainings());
  }, []);

  const formatDateTime = (dt: string) => {
    return new Date(dt).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <Layout>
      <section className="max-w-7xl mx-auto px-4 mb-16">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4">
            Master Your Skills with <span className="text-indigo-600">Brighters Academy</span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Choose from our professionally curated training programs designed to accelerate your career growth and English proficiency.
          </p>
        </div>

        {trainings.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
            <i className="fas fa-calendar-alt text-5xl text-slate-300 mb-4"></i>
            <h3 className="text-xl font-semibold text-slate-500">No active training sessions found</h3>
            <p className="text-slate-400">Please check back later for new course updates.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {trainings.sort((a,b) => b.createdAt - a.createdAt).map((training) => (
              <div key={training.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all group">
                <div className="relative h-48 bg-slate-200 overflow-hidden">
                  {training.image ? (
                    <img src={training.image} alt={training.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-indigo-50 text-indigo-200">
                      <i className="fas fa-image text-6xl"></i>
                    </div>
                  )}
                  <div className="absolute top-4 right-4 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                    ৳{training.fee}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-slate-900 mb-2 line-clamp-1">{training.name}</h3>
                  <div className="space-y-2 mb-6">
                    <div className="flex items-center text-sm text-slate-500">
                      <i className="fas fa-building w-5 text-indigo-500"></i>
                      <span>{training.organization}</span>
                    </div>
                    <div className="flex items-center text-sm text-slate-500">
                      <i className="fas fa-calendar-alt w-5 text-indigo-500"></i>
                      <span>{formatDateTime(training.dateTime)}</span>
                    </div>
                  </div>
                  
                  <p className="text-slate-600 text-sm mb-6 line-clamp-3 leading-relaxed">
                    {training.description}
                  </p>
                  
                  <div className="flex gap-3">
                    <Link 
                      to={`/details/${training.id}`}
                      className="flex-1 bg-slate-100 text-slate-700 py-3 rounded-xl font-semibold text-center hover:bg-slate-200 transition-colors"
                    >
                      Details
                    </Link>
                    <a 
                      href={training.applyLink || "https://forms.gle/default"} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-semibold text-center hover:bg-indigo-700 transition-all hover:shadow-lg shadow-indigo-100"
                    >
                      Apply Now
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Trust Section */}
      <section className="bg-white py-20 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="text-slate-400 font-bold uppercase tracking-widest text-sm mb-12">Trusted by students from</h3>
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50 grayscale hover:grayscale-0 transition-all">
            <span className="text-2xl font-bold text-slate-800">BRAC University</span>
            <span className="text-2xl font-bold text-slate-800">NSU</span>
            <span className="text-2xl font-bold text-slate-800">DU</span>
            <span className="text-2xl font-bold text-slate-800">BUET</span>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default LandingPage;
