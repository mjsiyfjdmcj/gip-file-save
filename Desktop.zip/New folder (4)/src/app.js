// Application State
const state = {
    activeView: 'dashboard',
    messages: [],
    isLoading: false,
    navItems: [
        { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard', isActive: true },
        { id: 'policy', label: 'Policy Chat', icon: 'message-square', isActive: false },
        { id: 'talent', label: 'Talent Manager', icon: 'users', isActive: false },
        { id: 'settings', label: 'Settings', icon: 'settings', isActive: false }
    ]
};

// Mock Data
const sentimentData = [
    { period: 'Jan', score: 0.75, volume: 120, topKeywords: ['benefits', 'culture'] },
    { period: 'Feb', score: 0.68, volume: 135, topKeywords: ['workload', 'support'] },
    { period: 'Mar', score: 0.82, volume: 98, topKeywords: ['growth', 'team'] },
    { period: 'Apr', score: 0.71, volume: 156, topKeywords: ['remote', 'flexibility'] }
];

const candidates = [
    { id: '1', name: 'Sarah Chen', stage: 'Interview', aiFitScore: 92 },
    { id: '2', name: 'Mike Johnson', stage: 'Screening', aiFitScore: 78 },
    { id: '3', name: 'Lisa Park', stage: 'Offer', aiFitScore: 95 }
];

// Utility Functions
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function formatTimestamp(timestamp) {
    return new Date(timestamp).toLocaleTimeString();
}

// Component Renderers
function renderNavigation() {
    const navContainer = document.getElementById('nav-items');
    navContainer.innerHTML = state.navItems.map(item => `
        <button 
            class="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors duration-200 ${
                item.isActive ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
            }"
            onclick="switchView('${item.id}')"
        >
            <i data-lucide="${item.icon}" class="w-5 h-5"></i>
            <span class="font-medium">${item.label}</span>
        </button>
    `).join('');
    lucide.createIcons();
}

function renderBreadcrumbs() {
    const activeItem = state.navItems.find(item => item.isActive);
    document.getElementById('breadcrumbs').textContent = `HR Pulse / ${activeItem.label}`;
}

function renderDashboard() {
    return `
        <div class="space-y-6">
            <h2 class="text-2xl font-bold text-slate-900">Dashboard Overview</h2>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-slate-500">Employee Satisfaction</p>
                            <p class="text-2xl font-bold text-slate-900">74%</p>
                        </div>
                        <i data-lucide="trending-up" class="w-8 h-8 text-green-500"></i>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-slate-500">Active Candidates</p>
                            <p class="text-2xl font-bold text-slate-900">${candidates.length}</p>
                        </div>
                        <i data-lucide="users" class="w-8 h-8 text-blue-500"></i>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-slate-500">Policy Queries</p>
                            <p class="text-2xl font-bold text-slate-900">127</p>
                        </div>
                        <i data-lucide="message-square" class="w-8 h-8 text-purple-500"></i>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <h3 class="text-lg font-semibold text-slate-900 mb-4">Employee Pulse</h3>
                    <div id="sentiment-chart" class="h-64"></div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <h3 class="text-lg font-semibold text-slate-900 mb-4">Feedback Volume</h3>
                    <div id="volume-chart" class="h-64"></div>
                </div>
            </div>
        </div>
    `;
}

function renderPolicyChat() {
    return `
        <div class="max-w-4xl mx-auto">
            <h2 class="text-2xl font-bold text-slate-900 mb-6">HR Policy Assistant</h2>
            
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col h-96">
                <div id="chat-messages" class="flex-1 p-4 overflow-y-auto space-y-4">
                    ${state.messages.map(msg => `
                        <div class="flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}">
                            <div class="max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                msg.role === 'user' 
                                    ? 'bg-indigo-500 text-white' 
                                    : 'bg-slate-100 text-slate-900'
                            }">
                                <div class="text-sm">${marked.parse(msg.content)}</div>
                                <div class="text-xs opacity-70 mt-1">${formatTimestamp(msg.timestamp)}</div>
                            </div>
                        </div>
                    `).join('')}
                    ${state.isLoading ? '<div class="flex justify-start"><div class="bg-slate-100 px-4 py-2 rounded-lg typing">AI is thinking</div></div>' : ''}
                </div>
                
                <div class="border-t border-slate-200 p-4">
                    <div class="flex gap-2">
                        <input 
                            id="chat-input" 
                            type="text" 
                            placeholder="Ask about HR policies..."
                            class="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            onkeypress="handleChatKeypress(event)"
                        >
                        <button 
                            onclick="sendMessage()" 
                            class="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
                        >
                            Send
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderTalentManager() {
    return `
        <div class="space-y-6">
            <h2 class="text-2xl font-bold text-slate-900">Talent Pipeline</h2>
            
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200">
                    <h3 class="text-lg font-semibold text-slate-900">Active Candidates</h3>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Stage</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">AI Fit Score</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200">
                            ${candidates.map(candidate => `
                                <tr class="hover:bg-slate-50">
                                    <td class="px-6 py-4 text-sm font-medium text-slate-900">${candidate.name}</td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                            candidate.stage === 'Offer' ? 'bg-green-100 text-green-800' :
                                            candidate.stage === 'Interview' ? 'bg-blue-100 text-blue-800' :
                                            'bg-yellow-100 text-yellow-800'
                                        }">
                                            ${candidate.stage}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-slate-900">${candidate.aiFitScore}%</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

// Event Handlers
function switchView(viewId) {
    state.navItems.forEach(item => item.isActive = item.id === viewId);
    state.activeView = viewId;
    render();
}

function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const content = input.value.trim();
    
    if (!content) return;
    
    // Add user message
    state.messages.push({
        id: generateId(),
        role: 'user',
        content,
        timestamp: Date.now()
    });
    
    input.value = '';
    state.isLoading = true;
    render();
    
    // Simulate AI response
    setTimeout(() => {
        const responses = [
            "According to our **Employee Handbook Section 3.2**, vacation requests should be submitted at least 2 weeks in advance through the HR portal.",
            "Our **Remote Work Policy** allows up to 3 days per week of remote work with manager approval. Please review the guidelines in Section 5.1.",
            "For **Performance Review** questions, please refer to our annual review process outlined in Section 7. Reviews are conducted quarterly with formal evaluations annually."
        ];
        
        state.messages.push({
            id: generateId(),
            role: 'model',
            content: responses[Math.floor(Math.random() * responses.length)],
            timestamp: Date.now()
        });
        
        state.isLoading = false;
        render();
        
        // Auto-scroll to bottom
        const chatContainer = document.getElementById('chat-messages');
        if (chatContainer) {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    }, 1500);
}

// Main Render Function
function render() {
    const viewContainer = document.getElementById('view-container');
    
    switch (state.activeView) {
        case 'dashboard':
            viewContainer.innerHTML = renderDashboard();
            renderCharts();
            break;
        case 'policy':
            viewContainer.innerHTML = renderPolicyChat();
            break;
        case 'talent':
            viewContainer.innerHTML = renderTalentManager();
            break;
        default:
            viewContainer.innerHTML = '<div class="text-center text-slate-500">View not implemented</div>';
    }
    
    renderNavigation();
    renderBreadcrumbs();
    lucide.createIcons();
}

function renderCharts() {
    // Simple chart rendering using canvas
    setTimeout(() => {
        const sentimentChart = document.getElementById('sentiment-chart');
        const volumeChart = document.getElementById('volume-chart');
        
        if (sentimentChart) {
            sentimentChart.innerHTML = `
                <div class="space-y-2">
                    ${sentimentData.map(data => `
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-slate-600">${data.period}</span>
                            <div class="flex-1 mx-3 bg-slate-200 rounded-full h-2">
                                <div class="bg-indigo-500 h-2 rounded-full" style="width: ${data.score * 100}%"></div>
                            </div>
                            <span class="text-sm font-medium">${Math.round(data.score * 100)}%</span>
                        </div>
                    `).join('')}
                </div>
            `;
        }
        
        if (volumeChart) {
            volumeChart.innerHTML = `
                <div class="space-y-2">
                    ${sentimentData.map(data => `
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-slate-600">${data.period}</span>
                            <div class="flex-1 mx-3 bg-slate-200 rounded-full h-2">
                                <div class="bg-blue-500 h-2 rounded-full" style="width: ${(data.volume / 200) * 100}%"></div>
                            </div>
                            <span class="text-sm font-medium">${data.volume}</span>
                        </div>
                    `).join('')}
                </div>
            `;
        }
    }, 100);
}

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    render();
});