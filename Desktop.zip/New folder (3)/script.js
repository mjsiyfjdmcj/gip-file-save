// Constants and Data
const TEMPLATES = [
    {
        id: 't1',
        name: 'Nebula Ultra',
        description: 'Our most stunning creation. High-frame animations, glassmorphism, and dynamic 3D elements.',
        category: 'Personal Portfolio',
        price: 200,
        beautyScore: 10,
        imageUrl: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['3D Hero Section', 'Advanced Dark Mode', 'Interactive Background', 'Mobile Optimized']
    },
    {
        id: 't2',
        name: 'Zenith Portfolio',
        description: 'Clean, minimalist, and breathtakingly elegant. Perfect for modern creatives.',
        category: 'Personal Portfolio',
        price: 200,
        beautyScore: 9.5,
        imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Minimalist UI', 'Custom Typefaces', 'Smooth Page Transitions', 'Portfolio Gallery']
    },
    {
        id: 't3',
        name: 'Connect Portal',
        description: 'A professional training and course portal with a sleek modern interface.',
        category: 'Training & Courses',
        price: 500,
        beautyScore: 7,
        imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['LMS Integration', 'User Dashboard', 'Video Player', 'Quiz Module']
    },
    {
        id: 't4',
        name: 'Standard Pro',
        description: 'Highly functional business portal. Clean and balanced design for enterprise needs.',
        category: 'Business Portal',
        price: 500,
        beautyScore: 6.5,
        imageUrl: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['CRM Dashboard', 'Analytics Panel', 'Team Management', 'Data Export']
    },
    {
        id: 't5',
        name: 'Basic Corporate',
        description: 'Solid, dependable, and traditional. Focused on performance over visual flair.',
        category: 'Business Portal',
        price: 1000,
        beautyScore: 4,
        imageUrl: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Static Layout', 'Legacy Support', 'SEO Optimized', 'Fast Load Time']
    },
    {
        id: 't6',
        name: 'Legacy Personal',
        description: 'Simple personal site. No distractions, just your content.',
        category: 'Personal Portfolio',
        price: 1000,
        beautyScore: 3.5,
        imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Single Page', 'Text Focus', 'Contact Form', 'Clean Code']
    },
    {
        id: 't7',
        name: 'Aurora Blog',
        description: 'Modern blog template with stunning typography and smooth reading experience.',
        category: 'Modern Blog',
        price: 200,
        beautyScore: 9,
        imageUrl: 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Typography Focus', 'Reading Mode', 'Social Integration', 'SEO Optimized']
    },
    {
        id: 't8',
        name: 'Quantum Agency',
        description: 'Ultra-modern agency website with 3D elements and interactive animations.',
        category: 'Business Portal',
        price: 200,
        beautyScore: 9.8,
        imageUrl: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['3D Animations', 'WebGL Effects', 'Parallax Scrolling', 'Custom Cursor']
    },
    {
        id: 't9',
        name: 'Cyber Portfolio',
        description: 'Futuristic portfolio with neon effects and cyberpunk aesthetics.',
        category: 'Personal Portfolio',
        price: 200,
        beautyScore: 9.7,
        imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Neon Effects', 'Dark Theme', 'Animated Icons', 'Particle System']
    },
    {
        id: 't10',
        name: 'EduTech Hub',
        description: 'Advanced learning management system with interactive course modules.',
        category: 'Training & Courses',
        price: 500,
        beautyScore: 7.5,
        imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Course Management', 'Progress Tracking', 'Video Streaming', 'Certificates']
    },
    {
        id: 't11',
        name: 'Minimal Blog',
        description: 'Clean and simple blog focused on content and readability.',
        category: 'Modern Blog',
        price: 500,
        beautyScore: 6,
        imageUrl: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Clean Typography', 'Fast Loading', 'SEO Friendly', 'Comment System']
    },
    {
        id: 't12',
        name: 'Classic Business',
        description: 'Traditional business website with proven design patterns.',
        category: 'Business Portal',
        price: 1000,
        beautyScore: 5,
        imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop&crop=entropy&auto=format&q=80',
        features: ['Contact Forms', 'Service Pages', 'About Section', 'Gallery']
    }
];

// State management
let currentPage = 'HOME';
let currentFilter = 'All';
let isLoading = false;

// Page management
function setPage(page) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => {
        p.style.display = 'none';
        p.classList.remove('active');
    });
    
    // Show selected page
    const pageElement = document.getElementById(`${page.toLowerCase()}-page`);
    if (pageElement) {
        pageElement.style.display = 'block';
        setTimeout(() => pageElement.classList.add('active'), 10);
    }
    
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
    
    currentPage = page;
    
    // Scroll to top
    window.scrollTo(0, 0);
    
    // Load templates if templates page
    if (page === 'TEMPLATES') {
        renderTemplates();
    }
}

// Filter management
function setFilter(filter) {
    currentFilter = filter;
    
    // Update filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filter) {
            btn.classList.add('active');
        }
    });
    
    renderTemplates();
}

// Template rendering
function renderTemplates() {
    const grid = document.getElementById('templates-grid');
    if (!grid) return;
    
    const filteredTemplates = currentFilter === 'All' 
        ? TEMPLATES 
        : TEMPLATES.filter(t => t.category === currentFilter);
    
    grid.innerHTML = filteredTemplates.map(template => `
        <div class="product-card group glass-hover transition-all duration-500 hover:-translate-y-2 flex flex-col h-full">
            <div class="relative aspect-video overflow-hidden shrink-0">
                <img 
                    src="${template.imageUrl}" 
                    alt="${template.name}"
                    class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                
                <!-- Category Badge -->
                <div class="absolute top-4 left-4 z-10">
                    <div class="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/80">
                        ${template.category}
                    </div>
                </div>

                <!-- Beauty Score Badge -->
                <div class="absolute top-4 right-4 z-10">
                    <div class="bg-indigo-600/80 backdrop-blur-md px-2 py-1 rounded-lg border border-indigo-400/30 text-[10px] font-black text-white">
                        ${template.beautyScore}/10
                    </div>
                </div>

                <!-- Overlay -->
                <div class="overlay absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center">
                    <button onclick="openOrderModal('${template.id}')" class="bg-indigo-600 text-white px-6 py-3 rounded-full font-bold text-sm hover:bg-indigo-500 transition-all active:scale-95 mb-3">
                        ORDER NOW
                    </button>
                    <div class="text-xs text-gray-300 font-medium">Exclusive Design</div>
                </div>
            </div>
            
            <div class="p-7 flex flex-col flex-1">
                <div class="flex justify-between items-start mb-3">
                    <h3 class="text-xl font-bold text-white group-hover:text-indigo-400 transition-colors">${template.name}</h3>
                    <span class="text-2xl font-black text-indigo-400 leading-none">${template.price}৳</span>
                </div>
                
                <p class="text-gray-400 text-sm mb-6 line-clamp-2 leading-relaxed">
                    ${template.description}
                </p>

                <div class="mt-auto space-y-4">
                    <div class="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                        <div 
                            class="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 transition-all duration-1000 ease-out" 
                            style="width: ${template.beautyScore * 10}%"
                        ></div>
                    </div>

                    <div class="flex flex-wrap gap-2">
                        ${template.features.slice(0, 2).map(f => `
                            <span class="text-[9px] bg-white/5 px-2 py-1 rounded-md border border-white/5 text-gray-400 uppercase font-bold tracking-tighter">
                                ${f}
                            </span>
                        `).join('')}
                    </div>
                    
                    <button onclick="openOrderModal('${template.id}')" class="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-indigo-500 transition-all active:scale-95 mt-4">
                        ORDER NOW
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Chat functionality
function sendMessage() {
    const input = document.getElementById('chat-input');
    const messagesContainer = document.getElementById('chat-messages');
    const sendButton = document.getElementById('send-button');
    
    if (!input.value.trim() || isLoading) return;
    
    const userMessage = input.value.trim();
    input.value = '';
    
    // Add user message
    addMessage('user', userMessage);
    
    // Show loading
    isLoading = true;
    sendButton.disabled = true;
    showLoadingMessage();
    
    // Simulate AI response (replace with actual API call)
    setTimeout(() => {
        hideLoadingMessage();
        const response = getSimulatedResponse(userMessage);
        addMessage('assistant', response);
        isLoading = false;
        sendButton.disabled = false;
    }, 2000);
}

function addMessage(role, content) {
    const messagesContainer = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = role === 'user' ? 'message-user' : 'message-assistant';
    
    messageDiv.innerHTML = `
        <div class="${role === 'user' ? 'message-bubble-user' : 'message-bubble-assistant'}">
            <p class="text-sm leading-relaxed whitespace-pre-wrap">${content}</p>
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function showLoadingMessage() {
    const messagesContainer = document.getElementById('chat-messages');
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-message';
    loadingDiv.className = 'message-assistant';
    
    loadingDiv.innerHTML = `
        <div class="message-bubble-assistant">
            <div class="loading-dots">
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
            </div>
        </div>
    `;
    
    messagesContainer.appendChild(loadingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function hideLoadingMessage() {
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
        loadingMessage.remove();
    }
}

function getSimulatedResponse(userMessage) {
    const responses = [
        "Based on your requirements, I'd recommend our 200 Taka tier. The ultra-premium aesthetics will give you the visual impact you're looking for while remaining incredibly affordable.",
        "For a professional business presence, consider our 500 Taka Standard tier. It balances functionality with modern design principles perfectly.",
        "If you prefer minimalist, traditional design, our 1000 Taka Legacy tier focuses on performance and reliability over visual complexity.",
        "The beauty of our inverted pricing model is that the most stunning designs are the most accessible. What specific features are most important to your project?",
        "Our AI analysis suggests that your project would benefit from the advanced animations and glassmorphism effects available in our premium 200 Taka tier."
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the app
    setPage('HOME');
    
    // Chat input enter key
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Initialize filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => setFilter(btn.dataset.filter));
    });
    
    // Order form submission
    const orderForm = document.getElementById('order-form');
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(orderForm);
            const orderData = {
                template: document.getElementById('selected-template').textContent,
                price: document.getElementById('template-price').textContent,
                name: formData.get('name'),
                email: formData.get('email'),
                phone: formData.get('phone'),
                location: formData.get('location'),
                work: formData.get('work'),
                details: formData.get('details'),
                reference: formData.get('reference'),
                additional: formData.get('additional'),
                timestamp: new Date().toLocaleString('bn-BD')
            };
            
            console.log('Order Data:', orderData);
            alert('আপনার অর্ডার সফলভাবে পাঠানো হয়েছে! আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।');
            closeOrderModal();
        });
    }
    
    // Close modal on outside click
    const orderModal = document.getElementById('order-modal');
    if (orderModal) {
        orderModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeOrderModal();
            }
        });
    }
});

// Utility functions
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Mobile menu functions
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuBtn = document.getElementById('mobile-menu-btn');
    const icon = menuBtn.querySelector('i');
    
    if (mobileMenu.classList.contains('menu-open')) {
        closeMobileMenu();
    } else {
        openMobileMenu();
    }
}

function openMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuBtn = document.getElementById('mobile-menu-btn');
    const icon = menuBtn.querySelector('i');
    
    mobileMenu.classList.add('menu-open');
    mobileMenu.style.transform = 'translateY(0)';
    mobileMenu.style.opacity = '1';
    mobileMenu.style.pointerEvents = 'auto';
    icon.className = 'fa-solid fa-times text-xl';
}

function closeMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuBtn = document.getElementById('mobile-menu-btn');
    const icon = menuBtn.querySelector('i');
    
    mobileMenu.classList.remove('menu-open');
    mobileMenu.style.transform = 'translateY(-100%)';
    mobileMenu.style.opacity = '0';
    mobileMenu.style.pointerEvents = 'none';
    icon.className = 'fa-solid fa-bars text-xl';
}

// Export for global access
window.setPage = setPage;
window.setFilter = setFilter;
window.sendMessage = sendMessage;
window.toggleMobileMenu = toggleMobileMenu;
window.closeMobileMenu = closeMobileMenu;
window.openOrderModal = openOrderModal;
window.closeOrderModal = closeOrderModal;

// Order Modal Functions
function openOrderModal(templateId) {
    const template = TEMPLATES.find(t => t.id === templateId);
    if (!template) return;
    
    const modal = document.getElementById('order-modal');
    const selectedTemplate = document.getElementById('selected-template');
    const templatePrice = document.getElementById('template-price');
    
    selectedTemplate.textContent = template.name;
    templatePrice.textContent = template.price + '৳';
    
    modal.classList.remove('opacity-0', 'pointer-events-none');
    modal.classList.add('opacity-100');
    modal.querySelector('.glass').classList.remove('scale-95');
    modal.querySelector('.glass').classList.add('scale-100');
    
    document.body.style.overflow = 'hidden';
}

function closeOrderModal() {
    const modal = document.getElementById('order-modal');
    
    modal.classList.add('opacity-0', 'pointer-events-none');
    modal.classList.remove('opacity-100');
    modal.querySelector('.glass').classList.add('scale-95');
    modal.querySelector('.glass').classList.remove('scale-100');
    
    document.body.style.overflow = 'auto';
    
    document.getElementById('order-form').reset();
}