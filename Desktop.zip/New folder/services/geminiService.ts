
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION_POLICY } from "../constants";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const chatWithPolicyAI = async (message: string, history: any[]) => {
  const ai = getAIClient();
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION_POLICY,
    },
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};

export const generateJobDescription = async (params: {
  title: string;
  department: string;
  experience: string;
  keyRequirements: string;
}) => {
  const ai = getAIClient();
  const prompt = `Generate a modern, inclusive job description for:
    Title: ${params.title}
    Department: ${params.department}
    Experience Level: ${params.experience}
    Key Requirements: ${params.keyRequirements}
    
    Format the response with Markdown using sections: Role Overview, Key Responsibilities, Qualifications, and Benefits.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  return response.text;
};

export const draftPolicyContent = async (title: string, description: string, instructions?: string) => {
  const ai = getAIClient();
  const prompt = `Act as an expert HR Policy writer. Draft a comprehensive company policy for: "${title}".
    ${description ? `Initial context provided: ${description}` : ''}
    ${instructions ? `SPECIFIC USER INSTRUCTIONS TO FOLLOW: ${instructions}` : ''}
    
    The policy should be professional, clear, and include sections like Purpose, Scope, Policy Details, and Compliance.
    Output only the policy content in Markdown format. Ensure the tone is consistent with modern corporate standards.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  return response.text;
};

export const analyzeSentiment = async (feedback: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following employee feedback and provide a sentiment score (0-100 for Positive, Neutral, Negative) and a brief summary of the main themes: "${feedback}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          positive: { type: Type.NUMBER },
          neutral: { type: Type.NUMBER },
          negative: { type: Type.NUMBER },
          themes: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          summary: { type: Type.STRING }
        },
        required: ["positive", "neutral", "negative", "themes", "summary"]
      }
    }
  });

  return JSON.parse(response.text);
};
