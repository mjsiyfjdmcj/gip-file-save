
import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { MessageSquareText, ThumbsUp, ThumbsDown, Minus, Info } from 'lucide-react';
import { MOCK_SENTIMENT_DATA } from '../constants';
import { analyzeSentiment } from '../services/geminiService';

const SentimentAnalysis: React.FC = () => {
  const [feedbackInput, setFeedbackInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recentAnalysis, setRecentAnalysis] = useState<any>(null);

  const handleAnalyze = async () => {
    if (!feedbackInput.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await analyzeSentiment(feedbackInput);
      setRecentAnalysis(result);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-green-50 rounded-xl text-green-600">
            <ThumbsUp size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Positive Sentiment</p>
            <p className="text-2xl font-bold text-slate-800">65% <span className="text-xs text-green-500 font-normal">↑ 12%</span></p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
            <Minus size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Neutral Sentiment</p>
            <p className="text-2xl font-bold text-slate-800">25% <span className="text-xs text-slate-400 font-normal">↓ 4%</span></p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
            <ThumbsDown size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Negative Sentiment</p>
            <p className="text-2xl font-bold text-slate-800">10% <span className="text-xs text-green-500 font-normal">↓ 8%</span></p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Trend Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-800 mb-6">Sentiment Trend (6 Months)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_SENTIMENT_DATA}>
                <defs>
                  <linearGradient id="colorPos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Area type="monotone" dataKey="positive" stroke="#10b981" fillOpacity={1} fill="url(#colorPos)" strokeWidth={2} />
                <Area type="monotone" dataKey="neutral" stroke="#3b82f6" fillOpacity={0} strokeWidth={2} />
                <Area type="monotone" dataKey="negative" stroke="#ef4444" fillOpacity={0} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Real-time Feedback Analysis */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <MessageSquareText className="text-indigo-600" size={20} />
            Instant Feedback Analyzer
          </h3>
          <div className="flex-1 space-y-4">
            <textarea
              className="w-full h-32 bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm focus:ring-2 focus:ring-indigo-500/20"
              placeholder="Paste employee feedback here to analyze sentiment and themes..."
              value={feedbackInput}
              onChange={(e) => setFeedbackInput(e.target.value)}
            />
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !feedbackInput.trim()}
              className="w-full bg-slate-800 text-white font-semibold py-3 rounded-xl hover:bg-slate-900 transition-all flex items-center justify-center gap-2"
            >
              {isAnalyzing ? "Processing..." : "Analyze Sentiment"}
            </button>

            {recentAnalysis && (
              <div className="mt-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-indigo-900">AI Insights</h4>
                  <div className="flex gap-2 text-xs">
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded">Pos: {recentAnalysis.positive}%</span>
                    <span className="bg-red-100 text-red-700 px-2 py-1 rounded">Neg: {recentAnalysis.negative}%</span>
                  </div>
                </div>
                <p className="text-sm text-indigo-800 mb-4">{recentAnalysis.summary}</p>
                <div className="flex flex-wrap gap-2">
                  {recentAnalysis.themes.map((theme: string, i: number) => (
                    <span key={i} className="bg-white px-2 py-1 rounded text-xs font-medium text-slate-600 border border-indigo-100">#{theme}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SentimentAnalysis;
