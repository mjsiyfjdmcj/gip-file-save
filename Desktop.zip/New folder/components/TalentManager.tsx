
import React, { useState } from 'react';
import { Wand2, Copy, CheckCircle2, Loader2, Sparkles } from 'lucide-react';
import { generateJobDescription } from '../services/geminiService';

const TalentManager: React.FC = () => {
  const [params, setParams] = useState({
    title: '',
    department: 'Engineering',
    experience: 'Senior',
    keyRequirements: ''
  });
  const [result, setResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!params.title || !params.keyRequirements) return;
    setIsGenerating(true);
    try {
      const jd = await generateJobDescription(params);
      setResult(jd || '');
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <Sparkles className="text-indigo-600" size={20} />
            Job Description Generator
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Job Title</label>
              <input 
                type="text" 
                value={params.title}
                onChange={(e) => setParams({...params, title: e.target.value})}
                placeholder="e.g. Senior Frontend Engineer"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                <select 
                  value={params.department}
                  onChange={(e) => setParams({...params, department: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm"
                >
                  <option>Engineering</option>
                  <option>Marketing</option>
                  <option>Design</option>
                  <option>Product</option>
                  <option>Sales</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Level</label>
                <select 
                  value={params.experience}
                  onChange={(e) => setParams({...params, experience: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm"
                >
                  <option>Junior</option>
                  <option>Mid-level</option>
                  <option>Senior</option>
                  <option>Lead/Manager</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Key Requirements & Skills</label>
              <textarea 
                rows={4}
                value={params.keyRequirements}
                onChange={(e) => setParams({...params, keyRequirements: e.target.value})}
                placeholder="Enter 3-5 core requirements..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !params.title}
              className="w-full bg-indigo-600 text-white font-semibold py-3 rounded-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
            >
              {isGenerating ? <Loader2 className="animate-spin" size={20} /> : <Wand2 size={20} />}
              Generate with AI
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col min-h-[500px]">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-600">AI Generated Content</span>
          {result && (
            <button 
              onClick={copyToClipboard}
              className="text-slate-500 hover:text-indigo-600 transition-colors flex items-center gap-1.5 text-sm"
            >
              {copied ? <CheckCircle2 size={16} className="text-green-500" /> : <Copy size={16} />}
              {copied ? 'Copied' : 'Copy JD'}
            </button>
          )}
        </div>
        <div className="flex-1 p-6 overflow-y-auto bg-slate-50/30">
          {!result && !isGenerating ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                <Wand2 size={32} />
              </div>
              <p className="max-w-[250px]">Fill in the details on the left to generate a professional JD</p>
            </div>
          ) : isGenerating ? (
            <div className="h-full flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="animate-spin text-indigo-600" size={40} />
                <p className="text-slate-500 font-medium animate-pulse">Crafting the perfect role...</p>
              </div>
            </div>
          ) : (
            <div className="prose prose-sm max-w-none text-slate-700 whitespace-pre-wrap font-mono">
              {result}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TalentManager;
