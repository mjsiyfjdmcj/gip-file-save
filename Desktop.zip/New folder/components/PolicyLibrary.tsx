
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plus, 
  FileText, 
  Edit3, 
  Trash2, 
  Wand2, 
  ChevronRight, 
  History,
  X,
  CheckCircle2,
  Loader2,
  Sparkle,
  Filter,
  Lightbulb,
  RotateCcw,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Policy, PolicyVersion } from '../types';
import { draftPolicyContent } from '../services/geminiService';

const STORAGE_KEY = 'hr_pulse_policies';

const INITIAL_POLICIES: Policy[] = [
  {
    id: '1',
    title: 'Remote Work Policy',
    content: 'All employees are eligible for remote work subject to manager approval...',
    version: '2.1',
    lastUpdated: '2024-03-12',
    category: 'Workplace',
    history: []
  },
  {
    id: '2',
    title: 'Unlimited PTO Guidelines',
    content: 'We trust our employees to manage their time and take the rest they need...',
    version: '1.4',
    lastUpdated: '2024-01-05',
    category: 'Benefits',
    history: []
  },
  {
    id: '3',
    title: 'Code of Conduct',
    content: 'Our core values guide every interaction at PulseTech...',
    version: '3.0',
    lastUpdated: '2024-05-20',
    category: 'Conduct',
    history: []
  }
];

const CATEGORIES = ['General', 'Benefits', 'Workplace', 'Compliance', 'Conduct'];

const PolicyLibrary: React.FC = () => {
  const [policies, setPolicies] = useState<Policy[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : INITIAL_POLICIES;
  });
  const [editingPolicy, setEditingPolicy] = useState<Policy | null>(null);
  const [draftInstructions, setDraftInstructions] = useState('');
  const [isDrafting, setIsDrafting] = useState(false);
  const [activeFilter, setActiveFilter] = useState('All');
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(policies));
  }, [policies]);

  const filteredPolicies = useMemo(() => {
    if (activeFilter === 'All') return policies;
    return policies.filter(p => p.category === activeFilter);
  }, [policies, activeFilter]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPolicy) return;

    const existingPolicy = policies.find(p => p.id === editingPolicy.id);
    let updatedPolicies;

    if (existingPolicy) {
      // Create a history snapshot of the current state before overwriting
      const historyEntry: PolicyVersion = {
        content: existingPolicy.content,
        version: existingPolicy.version,
        lastUpdated: existingPolicy.lastUpdated,
        timestamp: Date.now()
      };
      
      const updatedHistory = existingPolicy.history ? [...existingPolicy.history, historyEntry] : [historyEntry];
      
      const updatedPolicy: Policy = {
        ...editingPolicy,
        lastUpdated: new Date().toISOString().split('T')[0],
        history: updatedHistory
      };
      
      updatedPolicies = policies.map(p => p.id === editingPolicy.id ? updatedPolicy : p);
    } else {
      const newPolicy: Policy = {
        ...editingPolicy,
        history: []
      };
      updatedPolicies = [...policies, newPolicy];
    }

    setPolicies(updatedPolicies);
    setEditingPolicy(null);
    setDraftInstructions('');
    setShowHistory(false);
  };

  const handleRevert = (version: PolicyVersion) => {
    if (!editingPolicy) return;
    if (confirm(`Are you sure you want to revert to version ${version.version}? Your current unsaved changes will be lost.`)) {
      setEditingPolicy({
        ...editingPolicy,
        content: version.content,
        version: version.version
      });
      setShowHistory(false);
    }
  };

  const startNew = () => {
    setDraftInstructions('');
    setShowHistory(false);
    setEditingPolicy({
      id: Date.now().toString(),
      title: '',
      content: '',
      version: '1.0',
      lastUpdated: new Date().toISOString().split('T')[0],
      category: 'General',
      history: []
    });
  };

  const handleAIDraft = async () => {
    if (!editingPolicy?.title) return;
    setIsDrafting(true);
    try {
      const content = await draftPolicyContent(
        editingPolicy.title, 
        editingPolicy.content, 
        draftInstructions
      );
      setEditingPolicy({ ...editingPolicy, content: content || '' });
    } catch (error) {
      console.error(error);
    } finally {
      setIsDrafting(false);
    }
  };

  const deletePolicy = (id: string) => {
    if (confirm('Are you sure you want to delete this policy? This will also delete its entire version history.')) {
      setPolicies(policies.filter(p => p.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      {!editingPolicy ? (
        <>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Policy Library</h3>
              <p className="text-sm text-slate-500">View and manage internal company guidelines with full versioning.</p>
            </div>
            <button 
              onClick={startNew}
              className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 hover:bg-indigo-700 transition-colors self-start shadow-sm"
            >
              <Plus size={18} />
              New Policy
            </button>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <div className="flex items-center gap-2 text-slate-400 mr-2 shrink-0">
              <Filter size={16} />
              <span className="text-xs font-bold uppercase tracking-wider">Filter:</span>
            </div>
            {['All', ...CATEGORIES].map(cat => (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap border ${
                  activeFilter === cat 
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm' 
                    : 'bg-white border-slate-200 text-slate-500 hover:border-indigo-300 hover:text-indigo-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPolicies.length > 0 ? (
              filteredPolicies.map(policy => (
                <div key={policy.id} className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-indigo-300 transition-all group shadow-sm flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2.5 bg-indigo-50 rounded-xl text-indigo-600">
                      <FileText size={20} />
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => setEditingPolicy(policy)} className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
                        <Edit3 size={16} />
                      </button>
                      <button onClick={() => deletePolicy(policy.id)} className="p-2 text-slate-400 hover:text-red-600 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  <h4 className="font-bold text-slate-800 mb-1 leading-tight">{policy.title}</h4>
                  <p className="text-[10px] text-slate-400 mb-4 flex flex-wrap gap-x-3 gap-y-1">
                    <span className="flex items-center gap-1 font-medium"><History size={10} /> v{policy.version}</span>
                    <span className="flex items-center gap-1 font-medium">Updated: {policy.lastUpdated}</span>
                    {policy.history && policy.history.length > 0 && (
                      <span className="flex items-center gap-1 font-medium text-indigo-400"><RotateCcw size={10} /> {policy.history.length} revs</span>
                    )}
                  </p>
                  <div className="mt-auto flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                      {policy.category}
                    </span>
                    <button onClick={() => setEditingPolicy(policy)} className="text-xs font-bold text-slate-400 hover:text-indigo-600 flex items-center gap-1 transition-colors">
                      Edit <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-12 flex flex-col items-center justify-center bg-white border border-dashed border-slate-200 rounded-2xl">
                <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mb-3">
                  <Filter size={24} />
                </div>
                <p className="text-slate-500 font-medium">No policies found in this category.</p>
                <button onClick={() => setActiveFilter('All')} className="mt-2 text-indigo-600 text-sm font-bold hover:underline">Clear filters</button>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-300">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                <FileText size={16} />
              </div>
              <h3 className="font-bold text-slate-800">
                {policies.find(p => p.id === editingPolicy.id) ? 'Edit Policy' : 'Create New Policy'}
              </h3>
            </div>
            <button onClick={() => { setEditingPolicy(null); setDraftInstructions(''); setShowHistory(false); }} className="text-slate-400 hover:text-slate-600 p-2 transition-colors">
              <X size={20} />
            </button>
          </div>
          <form onSubmit={handleSave} className="p-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Policy Title</label>
                  <input 
                    required
                    type="text" 
                    value={editingPolicy.title}
                    onChange={e => setEditingPolicy({...editingPolicy, title: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    placeholder="e.g. Employee Wellness Program"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Version</label>
                    <input 
                      type="text" 
                      value={editingPolicy.version}
                      onChange={e => setEditingPolicy({...editingPolicy, version: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Category</label>
                    <select 
                      value={editingPolicy.category}
                      onChange={e => setEditingPolicy({...editingPolicy, category: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      {CATEGORIES.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-5 space-y-3 shadow-inner">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
                    <Sparkle size={14} />
                    AI Draft Refinement
                  </label>
                </div>
                <p className="text-[11px] text-indigo-600/70 font-medium">
                  Provide specific instructions to guide the AI drafting.
                </p>
                <div className="flex gap-2">
                  <input 
                    type="text"
                    value={draftInstructions}
                    onChange={e => setDraftInstructions(e.target.value)}
                    placeholder="Enter instructions or keywords..."
                    className="flex-1 bg-white border border-indigo-100 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none shadow-sm"
                  />
                  <button 
                    type="button"
                    onClick={handleAIDraft}
                    disabled={isDrafting || !editingPolicy.title}
                    className="bg-indigo-600 text-white text-xs font-bold px-5 py-2.5 rounded-xl flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-md shrink-0"
                  >
                    {isDrafting ? <Loader2 size={12} className="animate-spin" /> : <Wand2 size={12} />}
                    {editingPolicy.content ? 'Refine' : 'Generate'}
                  </button>
                </div>
              </div>
            </div>

            <div className="relative">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Policy Body (Markdown Supported)</label>
              <textarea 
                rows={12}
                value={editingPolicy.content}
                onChange={e => setEditingPolicy({...editingPolicy, content: e.target.value})}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-5 text-sm font-mono text-slate-700 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all resize-none shadow-sm"
                placeholder="Write the policy details here..."
              />
            </div>

            {/* Version History Tool */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
              <button 
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors text-slate-600"
              >
                <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
                  <History size={16} className="text-indigo-600" />
                  Version History 
                  {editingPolicy.history && editingPolicy.history.length > 0 && (
                    <span className="bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full ml-1">{editingPolicy.history.length}</span>
                  )}
                </div>
                {showHistory ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </button>
              
              {showHistory && (
                <div className="border-t border-slate-100 p-4 bg-slate-50/30">
                  {editingPolicy.history && editingPolicy.history.length > 0 ? (
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2 scrollbar-thin">
                      {[...editingPolicy.history].reverse().map((v, i) => (
                        <div key={i} className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between hover:shadow-sm transition-shadow">
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-700">v{v.version}</span>
                            <span className="text-[10px] text-slate-400 font-medium">Archived on: {v.lastUpdated}</span>
                          </div>
                          <button 
                            type="button"
                            onClick={() => handleRevert(v)}
                            className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors"
                          >
                            <RotateCcw size={14} />
                            Revert
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-400 text-center py-4 italic">No previous versions available for this policy.</p>
                  )}
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-100">
              <span className="text-xs font-medium text-slate-400 bg-slate-100 px-3 py-1 rounded-full">ID: {editingPolicy.id}</span>
              <div className="flex gap-3 w-full sm:w-auto">
                <button 
                  type="button"
                  onClick={() => { setEditingPolicy(null); setDraftInstructions(''); setShowHistory(false); }}
                  className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
                >
                  Discard
                </button>
                <button 
                  type="submit"
                  className="flex-1 sm:flex-none bg-slate-800 text-white px-8 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-900 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <CheckCircle2 size={18} />
                  Confirm & Save
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default PolicyLibrary;
