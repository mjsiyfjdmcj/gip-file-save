
import React from 'react';
import { 
  Users, 
  Calendar, 
  Clock, 
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { AppView } from '../types';

interface DashboardProps {
  onNavigate: (view: AppView) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Welcome back, HR Partner</h1>
          <p className="text-slate-500">Here's what's happening at PulseTech today.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 flex items-center gap-2 text-sm font-medium text-slate-600">
            <Calendar size={18} />
            <span>June 15, 2024</span>
          </div>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Employees', value: '1,248', icon: <Users />, color: 'bg-blue-500' },
          { label: 'Pending Reviews', value: '14', icon: <Clock />, color: 'bg-amber-500' },
          { label: 'Retention Rate', value: '96%', icon: <TrendingUp />, color: 'bg-emerald-500' },
          { label: 'Open Roles', value: '32', icon: <AlertCircle />, color: 'bg-indigo-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center text-white mb-4`}>
              {stat.icon}
            </div>
            <p className="text-sm font-medium text-slate-500 mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Actions */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-lg font-semibold text-slate-800">Quick AI Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
              onClick={() => onNavigate(AppView.POLICY_CHAT)}
              className="group bg-white p-6 rounded-2xl border border-slate-200 hover:border-indigo-500 transition-all text-left"
            >
              <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 flex items-center gap-2 mb-2">
                Policy Assistant
                <ArrowRight size={16} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
              </h3>
              <p className="text-sm text-slate-500">Get instant answers to complex HR policy questions using AI.</p>
            </button>
            <button 
              onClick={() => onNavigate(AppView.TALENT_TOOLS)}
              className="group bg-white p-6 rounded-2xl border border-slate-200 hover:border-indigo-500 transition-all text-left"
            >
              <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 flex items-center gap-2 mb-2">
                Draft Job Description
                <ArrowRight size={16} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
              </h3>
              <p className="text-sm text-slate-500">Generate inclusive, high-quality job postings in seconds.</p>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-800">Recent Notifications</h3>
              <button className="text-xs text-indigo-600 font-semibold uppercase tracking-wider">Clear All</button>
            </div>
            <div className="divide-y divide-slate-100">
              {[
                { title: 'Sentiment Dip Detected', time: '2 hours ago', type: 'alert' },
                { title: '3 New Candidates for Senior Dev', time: '4 hours ago', type: 'info' },
                { title: 'Performance Cycle Completed', time: 'Yesterday', type: 'success' },
              ].map((note, i) => (
                <div key={i} className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                  <div className={`w-2 h-2 rounded-full ${note.type === 'alert' ? 'bg-red-500' : note.type === 'success' ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-800">{note.title}</p>
                    <p className="text-xs text-slate-400">{note.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar content for Dashboard */}
        <div className="space-y-6">
          <div className="bg-indigo-900 rounded-2xl p-6 text-white overflow-hidden relative">
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-2">Pulse AI Insight</h3>
              <p className="text-indigo-100 text-sm mb-4 leading-relaxed">
                "Team morale in Marketing is at an all-time high this quarter. Consider sharing their hybrid-work success story with the rest of the org."
              </p>
              <div className="flex items-center gap-2 text-xs font-semibold bg-indigo-800/50 w-fit px-3 py-1.5 rounded-lg border border-indigo-700">
                <CheckCircle2 size={14} />
                CONFIDENCE: 94%
              </div>
            </div>
            <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-indigo-500 rounded-full blur-3xl opacity-20"></div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4">Pulse Checklist</h3>
            <ul className="space-y-3">
              {[
                { label: 'Q2 Planning Sync', done: true },
                { label: 'Review JD for Tech Lead', done: false },
                { label: 'Update PTO Guidelines', done: false },
              ].map((task, i) => (
                <li key={i} className="flex items-center gap-3 text-sm">
                  <div className={`w-5 h-5 rounded border ${task.done ? 'bg-indigo-600 border-indigo-600 flex items-center justify-center' : 'border-slate-300'}`}>
                    {task.done && <CheckCircle2 size={12} className="text-white" />}
                  </div>
                  <span className={task.done ? 'text-slate-400 line-through' : 'text-slate-600 font-medium'}>{task.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
